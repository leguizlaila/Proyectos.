﻿namespace CAE_Leguizamon2023
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            lblIngresarComo = new Label();
            BotonAdmin = new Button();
            BotonDocente = new Button();
            BotonAlumno = new Button();
            pictureBox1 = new PictureBox();
            lbCAE = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblIngresarComo
            // 
            lblIngresarComo.AutoSize = true;
            lblIngresarComo.Font = new Font("Mongolian Baiti", 11.25F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            lblIngresarComo.ForeColor = SystemColors.ActiveCaptionText;
            lblIngresarComo.Location = new Point(53, 251);
            lblIngresarComo.Name = "lblIngresarComo";
            lblIngresarComo.Size = new Size(115, 16);
            lblIngresarComo.TabIndex = 1;
            lblIngresarComo.Text = "Ingresar como:";
            // 
            // BotonAdmin
            // 
            BotonAdmin.BackColor = SystemColors.ButtonHighlight;
            BotonAdmin.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            BotonAdmin.Location = new Point(154, 281);
            BotonAdmin.Name = "BotonAdmin";
            BotonAdmin.Size = new Size(272, 42);
            BotonAdmin.TabIndex = 2;
            BotonAdmin.Text = "Administrador";
            BotonAdmin.UseVisualStyleBackColor = false;
            BotonAdmin.Click += BotonAdmin_Click;
            // 
            // BotonDocente
            // 
            BotonDocente.BackColor = SystemColors.ButtonHighlight;
            BotonDocente.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            BotonDocente.Location = new Point(154, 329);
            BotonDocente.Name = "BotonDocente";
            BotonDocente.Size = new Size(272, 42);
            BotonDocente.TabIndex = 3;
            BotonDocente.Text = "Docente";
            BotonDocente.UseVisualStyleBackColor = false;
            BotonDocente.Click += BotonDocente_Click;
            // 
            // BotonAlumno
            // 
            BotonAlumno.BackColor = SystemColors.ButtonHighlight;
            BotonAlumno.Font = new Font("Times New Roman", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            BotonAlumno.Location = new Point(154, 377);
            BotonAlumno.Name = "BotonAlumno";
            BotonAlumno.Size = new Size(272, 42);
            BotonAlumno.TabIndex = 4;
            BotonAlumno.Text = "Alumno";
            BotonAlumno.UseVisualStyleBackColor = false;
            BotonAlumno.Click += BotonAlumno_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(102, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(375, 183);
            pictureBox1.TabIndex = 5;
            pictureBox1.TabStop = false;
            // 
            // lbCAE
            // 
            lbCAE.AutoSize = true;
            lbCAE.BackColor = SystemColors.InactiveCaption;
            lbCAE.Font = new Font("Modern No. 20", 11.9999981F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lbCAE.Location = new Point(201, 198);
            lbCAE.Name = "lbCAE";
            lbCAE.Size = new Size(154, 18);
            lbCAE.TabIndex = 6;
            lbCAE.Text = "GESTIÓN DE CAE\r\n";
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(564, 450);
            Controls.Add(lbCAE);
            Controls.Add(pictureBox1);
            Controls.Add(BotonAlumno);
            Controls.Add(BotonDocente);
            Controls.Add(BotonAdmin);
            Controls.Add(lblIngresarComo);
            Name = "Home";
            Text = "Home";
            Load += Home_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblIngresarComo;
        private Button BotonAdmin;
        private Button BotonDocente;
        private Button BotonAlumno;
        private PictureBox pictureBox1;
        private Label lbCAE;
    }
}