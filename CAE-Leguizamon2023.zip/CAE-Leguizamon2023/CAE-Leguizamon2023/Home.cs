﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using CAE_Leguizamon2023.Login.c;
using CAE_Leguizamon2023.Funciones.Administrador;

namespace CAE_Leguizamon2023
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void LogoUC_Click(object sender, EventArgs e)
        {

        }

        public void BotonAdmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form VenLogin = new VentanaLogAd();
            VenLogin.Show();

        }

        private void BotonDocente_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form VentLog2 = new LoginDocente();
            VentLog2.Show();
        }

        private void BotonAlumno_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form VentLog3 = new LoginAlumno();
            VentLog3.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form adminf = new AdminFunciones();
            adminf.Show();
        }

        private void Home_Load(object sender, EventArgs e)
        {

        }
    }
}
