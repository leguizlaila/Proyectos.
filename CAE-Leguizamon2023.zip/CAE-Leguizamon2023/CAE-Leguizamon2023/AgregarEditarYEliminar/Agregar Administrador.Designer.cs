﻿namespace CAE_Leguizamon2023.AgregarEditarYEliminar
{
    partial class Agregar_Administrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DGVADMIN = new DataGridView();
            ColumnaCi = new DataGridViewTextBoxColumn();
            ColumnaNombre = new DataGridViewTextBoxColumn();
            ColumnaApellido = new DataGridViewTextBoxColumn();
            ColumnaContraseña = new DataGridViewTextBoxColumn();
            GBXAgregar = new GroupBox();
            BTNAGREGAR = new Button();
            TXB_CONTRASEÑA = new TextBox();
            TXB_MATERIA = new TextBox();
            TXB_APELLIDO = new TextBox();
            TXB_NOMBRE = new TextBox();
            TXB_CI = new TextBox();
            label2 = new Label();
            label1 = new Label();
            LBLAPELLIDO = new Label();
            LBLNOMBRE = new Label();
            LBLCI = new Label();
            LblAgregarDocente = new Label();
            GBXEliminar = new GroupBox();
            BTN_Eliminar = new Button();
            TXB_CIELIMINAR = new TextBox();
            label4 = new Label();
            LBLELIMINAR = new Label();
            BTN_Limpiar = new Button();
            BTNAtras = new Button();
            MensajeContraseña = new ToolTip(components);
            ((System.ComponentModel.ISupportInitialize)DGVADMIN).BeginInit();
            GBXAgregar.SuspendLayout();
            GBXEliminar.SuspendLayout();
            SuspendLayout();
            // 
            // DGVADMIN
            // 
            DGVADMIN.BackgroundColor = SystemColors.GradientInactiveCaption;
            DGVADMIN.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVADMIN.Columns.AddRange(new DataGridViewColumn[] { ColumnaCi, ColumnaNombre, ColumnaApellido, ColumnaContraseña });
            DGVADMIN.GridColor = SystemColors.InfoText;
            DGVADMIN.Location = new Point(3, 0);
            DGVADMIN.Name = "DGVADMIN";
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            DGVADMIN.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            DGVADMIN.RowTemplate.Height = 25;
            DGVADMIN.Size = new Size(444, 184);
            DGVADMIN.TabIndex = 2;
            // 
            // ColumnaCi
            // 
            ColumnaCi.FillWeight = 80F;
            ColumnaCi.HeaderText = "CI";
            ColumnaCi.Name = "ColumnaCi";
            // 
            // ColumnaNombre
            // 
            ColumnaNombre.HeaderText = "Nombre";
            ColumnaNombre.Name = "ColumnaNombre";
            // 
            // ColumnaApellido
            // 
            ColumnaApellido.HeaderText = "Apellido";
            ColumnaApellido.Name = "ColumnaApellido";
            // 
            // ColumnaContraseña
            // 
            ColumnaContraseña.HeaderText = "Contraseña";
            ColumnaContraseña.Name = "ColumnaContraseña";
            // 
            // GBXAgregar
            // 
            GBXAgregar.Controls.Add(BTNAGREGAR);
            GBXAgregar.Controls.Add(TXB_CONTRASEÑA);
            GBXAgregar.Controls.Add(TXB_MATERIA);
            GBXAgregar.Controls.Add(TXB_APELLIDO);
            GBXAgregar.Controls.Add(TXB_NOMBRE);
            GBXAgregar.Controls.Add(TXB_CI);
            GBXAgregar.Controls.Add(label2);
            GBXAgregar.Controls.Add(label1);
            GBXAgregar.Controls.Add(LBLAPELLIDO);
            GBXAgregar.Controls.Add(LBLNOMBRE);
            GBXAgregar.Controls.Add(LBLCI);
            GBXAgregar.Controls.Add(LblAgregarDocente);
            GBXAgregar.Location = new Point(12, 203);
            GBXAgregar.Name = "GBXAgregar";
            GBXAgregar.Size = new Size(291, 259);
            GBXAgregar.TabIndex = 3;
            GBXAgregar.TabStop = false;
            // 
            // BTNAGREGAR
            // 
            BTNAGREGAR.Location = new Point(194, 216);
            BTNAGREGAR.Name = "BTNAGREGAR";
            BTNAGREGAR.Size = new Size(81, 28);
            BTNAGREGAR.TabIndex = 22;
            BTNAGREGAR.Text = "AGREGAR";
            BTNAGREGAR.UseVisualStyleBackColor = true;
            BTNAGREGAR.Click += BTNAGREGAR_Click;
            // 
            // TXB_CONTRASEÑA
            // 
            TXB_CONTRASEÑA.Location = new Point(137, 170);
            TXB_CONTRASEÑA.Name = "TXB_CONTRASEÑA";
            TXB_CONTRASEÑA.Size = new Size(116, 23);
            TXB_CONTRASEÑA.TabIndex = 18;
            MensajeContraseña.SetToolTip(TXB_CONTRASEÑA, "La contraseña asignada por el administrador es provisoria, debe ser cambiada por el usuario una vez ingresado al sistema");
            TXB_CONTRASEÑA.TextChanged += TXB_CONTRASEÑA_TextChanged;
            // 
            // TXB_MATERIA
            // 
            TXB_MATERIA.Location = new Point(137, 139);
            TXB_MATERIA.Name = "TXB_MATERIA";
            TXB_MATERIA.Size = new Size(116, 23);
            TXB_MATERIA.TabIndex = 17;
            // 
            // TXB_APELLIDO
            // 
            TXB_APELLIDO.Location = new Point(137, 104);
            TXB_APELLIDO.Name = "TXB_APELLIDO";
            TXB_APELLIDO.Size = new Size(116, 23);
            TXB_APELLIDO.TabIndex = 16;
            // 
            // TXB_NOMBRE
            // 
            TXB_NOMBRE.Location = new Point(137, 73);
            TXB_NOMBRE.Name = "TXB_NOMBRE";
            TXB_NOMBRE.Size = new Size(116, 23);
            TXB_NOMBRE.TabIndex = 15;
            // 
            // TXB_CI
            // 
            TXB_CI.Location = new Point(137, 39);
            TXB_CI.Name = "TXB_CI";
            TXB_CI.Size = new Size(116, 23);
            TXB_CI.TabIndex = 14;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 145);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 13;
            label2.Text = "MATERIA:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 176);
            label1.Name = "label1";
            label1.Size = new Size(86, 15);
            label1.TabIndex = 12;
            label1.Text = "CONTRASEÑA:";
            // 
            // LBLAPELLIDO
            // 
            LBLAPELLIDO.AutoSize = true;
            LBLAPELLIDO.Location = new Point(23, 112);
            LBLAPELLIDO.Name = "LBLAPELLIDO";
            LBLAPELLIDO.Size = new Size(63, 15);
            LBLAPELLIDO.TabIndex = 11;
            LBLAPELLIDO.Text = "APELLIDO:";
            // 
            // LBLNOMBRE
            // 
            LBLNOMBRE.AutoSize = true;
            LBLNOMBRE.Location = new Point(24, 76);
            LBLNOMBRE.Name = "LBLNOMBRE";
            LBLNOMBRE.Size = new Size(59, 15);
            LBLNOMBRE.TabIndex = 10;
            LBLNOMBRE.Text = "NOMBRE:";
            // 
            // LBLCI
            // 
            LBLCI.AutoSize = true;
            LBLCI.Location = new Point(25, 42);
            LBLCI.Name = "LBLCI";
            LBLCI.Size = new Size(21, 15);
            LBLCI.TabIndex = 9;
            LBLCI.Text = "CI:";
            // 
            // LblAgregarDocente
            // 
            LblAgregarDocente.AutoSize = true;
            LblAgregarDocente.Location = new Point(0, 10);
            LblAgregarDocente.Name = "LblAgregarDocente";
            LblAgregarDocente.Size = new Size(158, 15);
            LblAgregarDocente.TabIndex = 3;
            LblAgregarDocente.Text = "AGREGAR ADMINISTRADOR:";
            // 
            // GBXEliminar
            // 
            GBXEliminar.Controls.Add(BTN_Eliminar);
            GBXEliminar.Controls.Add(TXB_CIELIMINAR);
            GBXEliminar.Controls.Add(label4);
            GBXEliminar.Controls.Add(LBLELIMINAR);
            GBXEliminar.Location = new Point(309, 213);
            GBXEliminar.Name = "GBXEliminar";
            GBXEliminar.Size = new Size(269, 114);
            GBXEliminar.TabIndex = 5;
            GBXEliminar.TabStop = false;
            // 
            // BTN_Eliminar
            // 
            BTN_Eliminar.Location = new Point(180, 63);
            BTN_Eliminar.Name = "BTN_Eliminar";
            BTN_Eliminar.Size = new Size(81, 28);
            BTN_Eliminar.TabIndex = 24;
            BTN_Eliminar.Text = "ELIMINAR";
            BTN_Eliminar.UseVisualStyleBackColor = true;
            BTN_Eliminar.Click += BTN_Eliminar_Click;
            // 
            // TXB_CIELIMINAR
            // 
            TXB_CIELIMINAR.Location = new Point(82, 34);
            TXB_CIELIMINAR.Name = "TXB_CIELIMINAR";
            TXB_CIELIMINAR.Size = new Size(116, 23);
            TXB_CIELIMINAR.TabIndex = 18;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(23, 37);
            label4.Name = "label4";
            label4.Size = new Size(21, 15);
            label4.TabIndex = 17;
            label4.Text = "CI:";
            // 
            // LBLELIMINAR
            // 
            LBLELIMINAR.AutoSize = true;
            LBLELIMINAR.Location = new Point(0, 0);
            LBLELIMINAR.Name = "LBLELIMINAR";
            LBLELIMINAR.Size = new Size(159, 15);
            LBLELIMINAR.TabIndex = 16;
            LBLELIMINAR.Text = "ELIMINAR ADMINISTRADOR:";
            // 
            // BTN_Limpiar
            // 
            BTN_Limpiar.Location = new Point(434, 434);
            BTN_Limpiar.Name = "BTN_Limpiar";
            BTN_Limpiar.Size = new Size(81, 28);
            BTN_Limpiar.TabIndex = 26;
            BTN_Limpiar.Text = "LIMPIAR";
            BTN_Limpiar.UseVisualStyleBackColor = true;
            BTN_Limpiar.Click += BTN_Limpiar_Click;
            // 
            // BTNAtras
            // 
            BTNAtras.Location = new Point(521, 434);
            BTNAtras.Name = "BTNAtras";
            BTNAtras.Size = new Size(81, 28);
            BTNAtras.TabIndex = 27;
            BTNAtras.Text = "ATRAS";
            BTNAtras.UseVisualStyleBackColor = true;
            BTNAtras.Click += BTNAtras_Click;
            // 
            // MensajeContraseña
            // 
            MensajeContraseña.Popup += toolTip1_Popup;
            // 
            // Agregar_Administrador
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(628, 483);
            Controls.Add(BTNAtras);
            Controls.Add(BTN_Limpiar);
            Controls.Add(GBXEliminar);
            Controls.Add(GBXAgregar);
            Controls.Add(DGVADMIN);
            Name = "Agregar_Administrador";
            Text = "Agregar_Administrador";
            ((System.ComponentModel.ISupportInitialize)DGVADMIN).EndInit();
            GBXAgregar.ResumeLayout(false);
            GBXAgregar.PerformLayout();
            GBXEliminar.ResumeLayout(false);
            GBXEliminar.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView DGVADMIN;
        private GroupBox GBXAgregar;
        private Button BTNAGREGAR;
        private TextBox TXB_CONTRASEÑA;
        private TextBox TXB_MATERIA;
        private TextBox TXB_APELLIDO;
        private TextBox TXB_NOMBRE;
        private TextBox TXB_CI;
        private Label label2;
        private Label label1;
        private Label LBLAPELLIDO;
        private Label LBLNOMBRE;
        private Label LBLCI;
        private Label LblAgregarDocente;
        private GroupBox GBXEliminar;
        private Button BTN_Eliminar;
        private TextBox TXB_CIELIMINAR;
        private Label label4;
        private Label LBLELIMINAR;
        private Button BTN_Limpiar;
        private Button BTNAtras;
        private ToolTip MensajeContraseña;
        private DataGridViewTextBoxColumn ColumnaCi;
        private DataGridViewTextBoxColumn ColumnaNombre;
        private DataGridViewTextBoxColumn ColumnaApellido;
        private DataGridViewTextBoxColumn ColumnaContraseña;
    }
}