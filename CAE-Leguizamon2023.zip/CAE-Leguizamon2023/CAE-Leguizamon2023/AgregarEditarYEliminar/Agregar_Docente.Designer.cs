﻿namespace CAE_Leguizamon2023.Funciones.Administrador
{
    partial class Agregar_Docente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DGVDOCENTES = new DataGridView();
            ColumnaCi = new DataGridViewTextBoxColumn();
            ColumnaNombre = new DataGridViewTextBoxColumn();
            ColumnaApellido = new DataGridViewTextBoxColumn();
            ColumnaMatricula = new DataGridViewTextBoxColumn();
            ColumnaContraseña = new DataGridViewTextBoxColumn();
            groupBox1 = new GroupBox();
            BTNAGREGAR = new Button();
            TXB_CONTRASEÑA = new TextBox();
            TXB_MATERIA = new TextBox();
            TXB_APELLIDO = new TextBox();
            TXB_NOMBRE = new TextBox();
            TXB_CI = new TextBox();
            label2 = new Label();
            label1 = new Label();
            LBLAPELLIDO = new Label();
            LBLNOMBRE = new Label();
            LBLCI = new Label();
            LblAgregarDocente = new Label();
            groupBox3 = new GroupBox();
            BTN_Eliminar = new Button();
            TXB_CIELIMINAR = new TextBox();
            label4 = new Label();
            LBLELIMINAR = new Label();
            BTN_Retroceder = new Button();
            BTN_Limpiar = new Button();
            ToolTipContraseña = new ToolTip(components);
            ((System.ComponentModel.ISupportInitialize)DGVDOCENTES).BeginInit();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // DGVDOCENTES
            // 
            DGVDOCENTES.BackgroundColor = SystemColors.GradientInactiveCaption;
            DGVDOCENTES.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVDOCENTES.Columns.AddRange(new DataGridViewColumn[] { ColumnaCi, ColumnaNombre, ColumnaApellido, ColumnaMatricula, ColumnaContraseña });
            DGVDOCENTES.GridColor = SystemColors.InfoText;
            DGVDOCENTES.Location = new Point(23, 12);
            DGVDOCENTES.Name = "DGVDOCENTES";
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            DGVDOCENTES.RowHeadersDefaultCellStyle = dataGridViewCellStyle1;
            DGVDOCENTES.RowTemplate.Height = 25;
            DGVDOCENTES.Size = new Size(564, 184);
            DGVDOCENTES.TabIndex = 1;
            // 
            // ColumnaCi
            // 
            ColumnaCi.FillWeight = 80F;
            ColumnaCi.HeaderText = "CI";
            ColumnaCi.Name = "ColumnaCi";
            // 
            // ColumnaNombre
            // 
            ColumnaNombre.HeaderText = "Nombre";
            ColumnaNombre.Name = "ColumnaNombre";
            // 
            // ColumnaApellido
            // 
            ColumnaApellido.HeaderText = "Apellido";
            ColumnaApellido.Name = "ColumnaApellido";
            // 
            // ColumnaMatricula
            // 
            ColumnaMatricula.HeaderText = "Materia";
            ColumnaMatricula.Name = "ColumnaMatricula";
            // 
            // ColumnaContraseña
            // 
            ColumnaContraseña.HeaderText = "Contraseña";
            ColumnaContraseña.Name = "ColumnaContraseña";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(BTNAGREGAR);
            groupBox1.Controls.Add(TXB_CONTRASEÑA);
            groupBox1.Controls.Add(TXB_MATERIA);
            groupBox1.Controls.Add(TXB_APELLIDO);
            groupBox1.Controls.Add(TXB_NOMBRE);
            groupBox1.Controls.Add(TXB_CI);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(LBLAPELLIDO);
            groupBox1.Controls.Add(LBLNOMBRE);
            groupBox1.Controls.Add(LBLCI);
            groupBox1.Controls.Add(LblAgregarDocente);
            groupBox1.Location = new Point(4, 202);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(291, 259);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Enter += groupBox1_Enter;
            // 
            // BTNAGREGAR
            // 
            BTNAGREGAR.Location = new Point(194, 216);
            BTNAGREGAR.Name = "BTNAGREGAR";
            BTNAGREGAR.Size = new Size(81, 28);
            BTNAGREGAR.TabIndex = 22;
            BTNAGREGAR.Text = "AGREGAR";
            BTNAGREGAR.UseVisualStyleBackColor = true;
            BTNAGREGAR.Click += BTNAGREGAR_Click;
            // 
            // TXB_CONTRASEÑA
            // 
            TXB_CONTRASEÑA.Location = new Point(137, 170);
            TXB_CONTRASEÑA.Name = "TXB_CONTRASEÑA";
            TXB_CONTRASEÑA.Size = new Size(116, 23);
            TXB_CONTRASEÑA.TabIndex = 18;
            ToolTipContraseña.SetToolTip(TXB_CONTRASEÑA, "La contraseña asignada por el administrador es provisoria, debe ser cambiada por el usuario una vez haya ingresado al sistema");
            // 
            // TXB_MATERIA
            // 
            TXB_MATERIA.Location = new Point(137, 139);
            TXB_MATERIA.Name = "TXB_MATERIA";
            TXB_MATERIA.Size = new Size(116, 23);
            TXB_MATERIA.TabIndex = 17;
            // 
            // TXB_APELLIDO
            // 
            TXB_APELLIDO.Location = new Point(137, 104);
            TXB_APELLIDO.Name = "TXB_APELLIDO";
            TXB_APELLIDO.Size = new Size(116, 23);
            TXB_APELLIDO.TabIndex = 16;
            // 
            // TXB_NOMBRE
            // 
            TXB_NOMBRE.Location = new Point(137, 73);
            TXB_NOMBRE.Name = "TXB_NOMBRE";
            TXB_NOMBRE.Size = new Size(116, 23);
            TXB_NOMBRE.TabIndex = 15;
            // 
            // TXB_CI
            // 
            TXB_CI.Location = new Point(137, 39);
            TXB_CI.Name = "TXB_CI";
            TXB_CI.Size = new Size(116, 23);
            TXB_CI.TabIndex = 14;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(22, 145);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 13;
            label2.Text = "MATERIA:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 176);
            label1.Name = "label1";
            label1.Size = new Size(86, 15);
            label1.TabIndex = 12;
            label1.Text = "CONTRASEÑA:";
            // 
            // LBLAPELLIDO
            // 
            LBLAPELLIDO.AutoSize = true;
            LBLAPELLIDO.Location = new Point(23, 112);
            LBLAPELLIDO.Name = "LBLAPELLIDO";
            LBLAPELLIDO.Size = new Size(63, 15);
            LBLAPELLIDO.TabIndex = 11;
            LBLAPELLIDO.Text = "APELLIDO:";
            // 
            // LBLNOMBRE
            // 
            LBLNOMBRE.AutoSize = true;
            LBLNOMBRE.Location = new Point(24, 76);
            LBLNOMBRE.Name = "LBLNOMBRE";
            LBLNOMBRE.Size = new Size(59, 15);
            LBLNOMBRE.TabIndex = 10;
            LBLNOMBRE.Text = "NOMBRE:";
            // 
            // LBLCI
            // 
            LBLCI.AutoSize = true;
            LBLCI.Location = new Point(25, 42);
            LBLCI.Name = "LBLCI";
            LBLCI.Size = new Size(21, 15);
            LBLCI.TabIndex = 9;
            LBLCI.Text = "CI:";
            // 
            // LblAgregarDocente
            // 
            LblAgregarDocente.AutoSize = true;
            LblAgregarDocente.Location = new Point(0, 10);
            LblAgregarDocente.Name = "LblAgregarDocente";
            LblAgregarDocente.Size = new Size(117, 15);
            LblAgregarDocente.TabIndex = 3;
            LblAgregarDocente.Text = "AGREGAR DOCENTE:";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(BTN_Eliminar);
            groupBox3.Controls.Add(TXB_CIELIMINAR);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(LBLELIMINAR);
            groupBox3.Location = new Point(301, 212);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(269, 114);
            groupBox3.TabIndex = 4;
            groupBox3.TabStop = false;
            groupBox3.Enter += groupBox3_Enter;
            // 
            // BTN_Eliminar
            // 
            BTN_Eliminar.Location = new Point(180, 63);
            BTN_Eliminar.Name = "BTN_Eliminar";
            BTN_Eliminar.Size = new Size(81, 28);
            BTN_Eliminar.TabIndex = 24;
            BTN_Eliminar.Text = "ELIMINAR";
            BTN_Eliminar.UseVisualStyleBackColor = true;
            BTN_Eliminar.Click += BTN_Eliminar_Click;
            // 
            // TXB_CIELIMINAR
            // 
            TXB_CIELIMINAR.Location = new Point(82, 34);
            TXB_CIELIMINAR.Name = "TXB_CIELIMINAR";
            TXB_CIELIMINAR.Size = new Size(116, 23);
            TXB_CIELIMINAR.TabIndex = 18;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(23, 37);
            label4.Name = "label4";
            label4.Size = new Size(21, 15);
            label4.TabIndex = 17;
            label4.Text = "CI:";
            // 
            // LBLELIMINAR
            // 
            LBLELIMINAR.AutoSize = true;
            LBLELIMINAR.Location = new Point(0, 0);
            LBLELIMINAR.Name = "LBLELIMINAR";
            LBLELIMINAR.Size = new Size(118, 15);
            LBLELIMINAR.TabIndex = 16;
            LBLELIMINAR.Text = "ELIMINAR DOCENTE:";
            // 
            // BTN_Retroceder
            // 
            BTN_Retroceder.Location = new Point(542, 444);
            BTN_Retroceder.Name = "BTN_Retroceder";
            BTN_Retroceder.Size = new Size(81, 28);
            BTN_Retroceder.TabIndex = 24;
            BTN_Retroceder.Text = "ATRAS";
            BTN_Retroceder.UseVisualStyleBackColor = true;
            BTN_Retroceder.Click += BTN_Retroceder_Click;
            // 
            // BTN_Limpiar
            // 
            BTN_Limpiar.Location = new Point(455, 444);
            BTN_Limpiar.Name = "BTN_Limpiar";
            BTN_Limpiar.Size = new Size(81, 28);
            BTN_Limpiar.TabIndex = 25;
            BTN_Limpiar.Text = "LIMPIAR";
            BTN_Limpiar.UseVisualStyleBackColor = true;
            BTN_Limpiar.Click += BTN_Limpiar_Click;
            // 
            // Agregar_Docente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(644, 484);
            Controls.Add(BTN_Limpiar);
            Controls.Add(BTN_Retroceder);
            Controls.Add(groupBox3);
            Controls.Add(groupBox1);
            Controls.Add(DGVDOCENTES);
            Name = "Agregar_Docente";
            Text = "Agregar_Docente";
            ((System.ComponentModel.ISupportInitialize)DGVDOCENTES).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView DGVDOCENTES;
        private GroupBox groupBox1;
        private Label LblAgregarDocente;
        private Label LBLCI;
        private Label LBLNOMBRE;
        private Label LBLAPELLIDO;
        private TextBox TXB_MATERIA;
        private TextBox TXB_APELLIDO;
        private TextBox TXB_NOMBRE;
        private TextBox TXB_CI;
        private Label label2;
        private Button BTNAGREGAR;
        private TextBox TXB_CONTRASEÑA;
        private Label label1;
        private GroupBox groupBox3;
        private Label LBLELIMINAR;
        private Button BTN_Eliminar;
        private TextBox TXB_CIELIMINAR;
        private Label label4;
        private Button BTN_Retroceder;
        private Button BTN_Limpiar;
        private DataGridViewTextBoxColumn ColumnaCi;
        private DataGridViewTextBoxColumn ColumnaNombre;
        private DataGridViewTextBoxColumn ColumnaApellido;
        private DataGridViewTextBoxColumn ColumnaMatricula;
        private DataGridViewTextBoxColumn ColumnaContraseña;
        private ToolTip ToolTipContraseña;
    }
}