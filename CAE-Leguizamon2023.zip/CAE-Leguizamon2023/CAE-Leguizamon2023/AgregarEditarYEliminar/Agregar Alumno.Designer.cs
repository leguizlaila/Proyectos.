﻿namespace CAE_Leguizamon2023.Funciones.Alumno.AgregarEditarYEliminar
{
    partial class Agregar_Alumno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DGVALUMNOS = new DataGridView();
            ColumnaCi = new DataGridViewTextBoxColumn();
            ColumnaNombre = new DataGridViewTextBoxColumn();
            ColumnaApellido = new DataGridViewTextBoxColumn();
            ColumnaMatricula = new DataGridViewTextBoxColumn();
            ColumnaCarrera = new DataGridViewTextBoxColumn();
            ColumnaContraseña = new DataGridViewTextBoxColumn();
            COLUMNACAE = new DataGridViewTextBoxColumn();
            LblAlumnos = new Label();
            LblAgregar = new Label();
            TBXCI = new TextBox();
            TBXNAME = new TextBox();
            TBXAPE = new TextBox();
            TBXMAT = new TextBox();
            TBXCARRERA = new TextBox();
            LBLCI = new Label();
            LBLNOMBRE = new Label();
            LBLAPELLIDO = new Label();
            LBLMATRICULA = new Label();
            LBLCARRERA = new Label();
            LBLELIMINAR = new Label();
            Matricula = new Label();
            TBXMatriculaEliminar = new TextBox();
            BTNELIMINAR = new Button();
            BTNAGREGAR = new Button();
            btnLimpiar = new Button();
            BtnAtras = new Button();
            TBXCONTRASEÑA = new TextBox();
            TBXCAE = new TextBox();
            LbContraseña = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)DGVALUMNOS).BeginInit();
            SuspendLayout();
            // 
            // DGVALUMNOS
            // 
            DGVALUMNOS.BackgroundColor = SystemColors.GradientInactiveCaption;
            DGVALUMNOS.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DGVALUMNOS.Columns.AddRange(new DataGridViewColumn[] { ColumnaCi, ColumnaNombre, ColumnaApellido, ColumnaMatricula, ColumnaCarrera, ColumnaContraseña, COLUMNACAE });
            DGVALUMNOS.GridColor = SystemColors.InfoText;
            DGVALUMNOS.Location = new Point(2, 29);
            DGVALUMNOS.Name = "DGVALUMNOS";
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            DGVALUMNOS.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            DGVALUMNOS.RowTemplate.Height = 25;
            DGVALUMNOS.Size = new Size(738, 184);
            DGVALUMNOS.TabIndex = 0;
            DGVALUMNOS.CellContentClick += dataGridView1_CellContentClick;
            // 
            // ColumnaCi
            // 
            ColumnaCi.FillWeight = 80F;
            ColumnaCi.HeaderText = "CI";
            ColumnaCi.Name = "ColumnaCi";
            // 
            // ColumnaNombre
            // 
            ColumnaNombre.HeaderText = "Nombre";
            ColumnaNombre.Name = "ColumnaNombre";
            // 
            // ColumnaApellido
            // 
            ColumnaApellido.HeaderText = "Apellido";
            ColumnaApellido.Name = "ColumnaApellido";
            // 
            // ColumnaMatricula
            // 
            ColumnaMatricula.HeaderText = "Matricula";
            ColumnaMatricula.Name = "ColumnaMatricula";
            // 
            // ColumnaCarrera
            // 
            ColumnaCarrera.HeaderText = "Carrera";
            ColumnaCarrera.Name = "ColumnaCarrera";
            // 
            // ColumnaContraseña
            // 
            ColumnaContraseña.HeaderText = "Contraseña";
            ColumnaContraseña.Name = "ColumnaContraseña";
            // 
            // COLUMNACAE
            // 
            COLUMNACAE.HeaderText = "CAE";
            COLUMNACAE.Name = "COLUMNACAE";
            // 
            // LblAlumnos
            // 
            LblAlumnos.AutoSize = true;
            LblAlumnos.Location = new Point(25, 11);
            LblAlumnos.Name = "LblAlumnos";
            LblAlumnos.Size = new Size(64, 15);
            LblAlumnos.TabIndex = 1;
            LblAlumnos.Text = "ALUMNOS";
            // 
            // LblAgregar
            // 
            LblAgregar.AutoSize = true;
            LblAgregar.Location = new Point(2, 249);
            LblAgregar.Name = "LblAgregar";
            LblAgregar.Size = new Size(116, 15);
            LblAgregar.TabIndex = 2;
            LblAgregar.Text = "AGREGAR ALUMNO:";
            // 
            // TBXCI
            // 
            TBXCI.Location = new Point(113, 275);
            TBXCI.Name = "TBXCI";
            TBXCI.Size = new Size(124, 23);
            TBXCI.TabIndex = 3;
            // 
            // TBXNAME
            // 
            TBXNAME.Location = new Point(113, 307);
            TBXNAME.Name = "TBXNAME";
            TBXNAME.Size = new Size(124, 23);
            TBXNAME.TabIndex = 4;
            // 
            // TBXAPE
            // 
            TBXAPE.Location = new Point(113, 340);
            TBXAPE.Name = "TBXAPE";
            TBXAPE.Size = new Size(124, 23);
            TBXAPE.TabIndex = 5;
            // 
            // TBXMAT
            // 
            TBXMAT.Location = new Point(113, 371);
            TBXMAT.Name = "TBXMAT";
            TBXMAT.Size = new Size(124, 23);
            TBXMAT.TabIndex = 6;
            // 
            // TBXCARRERA
            // 
            TBXCARRERA.Location = new Point(113, 402);
            TBXCARRERA.Name = "TBXCARRERA";
            TBXCARRERA.Size = new Size(124, 23);
            TBXCARRERA.TabIndex = 7;
            // 
            // LBLCI
            // 
            LBLCI.AutoSize = true;
            LBLCI.Location = new Point(12, 278);
            LBLCI.Name = "LBLCI";
            LBLCI.Size = new Size(21, 15);
            LBLCI.TabIndex = 8;
            LBLCI.Text = "CI:";
            // 
            // LBLNOMBRE
            // 
            LBLNOMBRE.AutoSize = true;
            LBLNOMBRE.Location = new Point(34, 312);
            LBLNOMBRE.Name = "LBLNOMBRE";
            LBLNOMBRE.Size = new Size(59, 15);
            LBLNOMBRE.TabIndex = 9;
            LBLNOMBRE.Text = "NOMBRE:";
            // 
            // LBLAPELLIDO
            // 
            LBLAPELLIDO.AutoSize = true;
            LBLAPELLIDO.Location = new Point(33, 345);
            LBLAPELLIDO.Name = "LBLAPELLIDO";
            LBLAPELLIDO.Size = new Size(63, 15);
            LBLAPELLIDO.TabIndex = 10;
            LBLAPELLIDO.Text = "APELLIDO:";
            // 
            // LBLMATRICULA
            // 
            LBLMATRICULA.AutoSize = true;
            LBLMATRICULA.Location = new Point(28, 374);
            LBLMATRICULA.Name = "LBLMATRICULA";
            LBLMATRICULA.Size = new Size(74, 15);
            LBLMATRICULA.TabIndex = 11;
            LBLMATRICULA.Text = "MATRICULA:";
            // 
            // LBLCARRERA
            // 
            LBLCARRERA.AutoSize = true;
            LBLCARRERA.Location = new Point(27, 407);
            LBLCARRERA.Name = "LBLCARRERA";
            LBLCARRERA.Size = new Size(61, 15);
            LBLCARRERA.TabIndex = 12;
            LBLCARRERA.Text = "CARRERA:";
            // 
            // LBLELIMINAR
            // 
            LBLELIMINAR.AutoSize = true;
            LBLELIMINAR.Location = new Point(306, 249);
            LBLELIMINAR.Name = "LBLELIMINAR";
            LBLELIMINAR.Size = new Size(117, 15);
            LBLELIMINAR.TabIndex = 15;
            LBLELIMINAR.Text = "ELIMINAR ALUMNO:";
            // 
            // Matricula
            // 
            Matricula.AutoSize = true;
            Matricula.Location = new Point(306, 281);
            Matricula.Name = "Matricula";
            Matricula.Size = new Size(21, 15);
            Matricula.TabIndex = 16;
            Matricula.Text = "CI:";
            // 
            // TBXMatriculaEliminar
            // 
            TBXMatriculaEliminar.Location = new Point(374, 278);
            TBXMatriculaEliminar.Name = "TBXMatriculaEliminar";
            TBXMatriculaEliminar.Size = new Size(124, 23);
            TBXMatriculaEliminar.TabIndex = 17;
            // 
            // BTNELIMINAR
            // 
            BTNELIMINAR.Location = new Point(448, 312);
            BTNELIMINAR.Name = "BTNELIMINAR";
            BTNELIMINAR.Size = new Size(81, 28);
            BTNELIMINAR.TabIndex = 20;
            BTNELIMINAR.Text = "ELIMINAR";
            BTNELIMINAR.UseVisualStyleBackColor = true;
            BTNELIMINAR.Click += BTNELIMINAR_Click;
            // 
            // BTNAGREGAR
            // 
            BTNAGREGAR.Location = new Point(215, 488);
            BTNAGREGAR.Name = "BTNAGREGAR";
            BTNAGREGAR.Size = new Size(81, 28);
            BTNAGREGAR.TabIndex = 21;
            BTNAGREGAR.Text = "AGREGAR";
            BTNAGREGAR.UseVisualStyleBackColor = true;
            BTNAGREGAR.Click += BTNAGREGAR_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(514, 471);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 26);
            btnLimpiar.TabIndex = 24;
            btnLimpiar.Text = "LIMPIAR";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // BtnAtras
            // 
            BtnAtras.Location = new Point(605, 471);
            BtnAtras.Name = "BtnAtras";
            BtnAtras.Size = new Size(75, 26);
            BtnAtras.TabIndex = 25;
            BtnAtras.Text = "ATRAS";
            BtnAtras.UseVisualStyleBackColor = true;
            BtnAtras.Click += BtnAtras_Click;
            // 
            // TBXCONTRASEÑA
            // 
            TBXCONTRASEÑA.Location = new Point(113, 431);
            TBXCONTRASEÑA.Name = "TBXCONTRASEÑA";
            TBXCONTRASEÑA.Size = new Size(124, 23);
            TBXCONTRASEÑA.TabIndex = 26;
            // 
            // TBXCAE
            // 
            TBXCAE.Location = new Point(113, 460);
            TBXCAE.Name = "TBXCAE";
            TBXCAE.Size = new Size(124, 23);
            TBXCAE.TabIndex = 27;
            // 
            // LbContraseña
            // 
            LbContraseña.AutoSize = true;
            LbContraseña.Location = new Point(24, 434);
            LbContraseña.Name = "LbContraseña";
            LbContraseña.Size = new Size(86, 15);
            LbContraseña.TabIndex = 28;
            LbContraseña.Text = "CONTRASEÑA:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(28, 467);
            label3.Name = "label3";
            label3.Size = new Size(74, 15);
            label3.TabIndex = 29;
            label3.Text = "HORAS CAE:";
            // 
            // Agregar_Alumno
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(740, 519);
            Controls.Add(label3);
            Controls.Add(LbContraseña);
            Controls.Add(TBXCAE);
            Controls.Add(TBXCONTRASEÑA);
            Controls.Add(BtnAtras);
            Controls.Add(btnLimpiar);
            Controls.Add(BTNAGREGAR);
            Controls.Add(BTNELIMINAR);
            Controls.Add(TBXMatriculaEliminar);
            Controls.Add(Matricula);
            Controls.Add(LBLELIMINAR);
            Controls.Add(LBLCARRERA);
            Controls.Add(LBLMATRICULA);
            Controls.Add(LBLAPELLIDO);
            Controls.Add(LBLNOMBRE);
            Controls.Add(LBLCI);
            Controls.Add(TBXCARRERA);
            Controls.Add(TBXMAT);
            Controls.Add(TBXAPE);
            Controls.Add(TBXNAME);
            Controls.Add(TBXCI);
            Controls.Add(LblAgregar);
            Controls.Add(LblAlumnos);
            Controls.Add(DGVALUMNOS);
            Name = "Agregar_Alumno";
            Text = "Agregar_Alumno";
            Load += Agregar_Alumno_Load;
            ((System.ComponentModel.ISupportInitialize)DGVALUMNOS).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView DGVALUMNOS;
        private Label LblAlumnos;
        private Label LblAgregar;
        private TextBox TBXCI;
        private TextBox TBXNAME;
        private TextBox TBXAPE;
        private TextBox TBXMAT;
        private TextBox TBXCARRERA;
        private Label LBLCI;
        private Label LBLNOMBRE;
        private Label LBLAPELLIDO;
        private Label LBLMATRICULA;
        private Label LBLCARRERA;
        private Label LBLELIMINAR;
        private Label Matricula;
        private TextBox TBXMatriculaEliminar;
        private Button BTNELIMINAR;
        private Button BTNAGREGAR;
        private Button btnLimpiar;
        private Button BtnAtras;
        private DataGridViewTextBoxColumn ColumnaCi;
        private DataGridViewTextBoxColumn ColumnaNombre;
        private DataGridViewTextBoxColumn ColumnaApellido;
        private DataGridViewTextBoxColumn ColumnaMatricula;
        private DataGridViewTextBoxColumn ColumnaCarrera;
        private DataGridViewTextBoxColumn ColumnaContraseña;
        private DataGridViewTextBoxColumn COLUMNACAE;
        private TextBox TBXCONTRASEÑA;
        private TextBox TBXCAE;
        private Label LbContraseña;
        private Label label3;
    }
}