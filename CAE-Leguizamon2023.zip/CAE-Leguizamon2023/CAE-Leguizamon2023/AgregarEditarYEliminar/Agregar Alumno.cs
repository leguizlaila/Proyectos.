﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using CAE_Leguizamon2023;
using CAE_Leguizamon2023.Funciones.Administrador;
using CAE_Leguizamon2023.Funciones.Docente;

namespace CAE_Leguizamon2023.Funciones.Alumno.AgregarEditarYEliminar
{
    public partial class Agregar_Alumno : Form
    {

        public Agregar_Alumno()
        {
            InitializeComponent();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Agregar_Alumno_Load(object sender, EventArgs e)
        {
            actualizarLista();

        }

        public void actualizarLista()
        {
            //leer el archivo y guardar como cadena
            string jsonString = File.ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAlumno.json");

            //parametros para deserializar
            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            //deserializamos y guardamos como lista de 'Alumnos'
            List<DatosAlumno> listaDatos = JsonSerializer.Deserialize<List<DatosAlumno>>(jsonString, opciones)!;

            //Agregamos cada elemento de la lista a la tabla
            foreach (DatosAlumno alumno in listaDatos)
            {
                DGVALUMNOS.Rows.Add
                    (alumno.Ci, alumno.nombre, alumno.apellido, alumno.matricula, alumno.carrera, alumno.Pass, alumno.CAE);
            }
        }

        private void BTNAGREGAR_Click(object sender, EventArgs e)
        {
            //leemos el archivo y guardamos como cadena
            string jsonString = File.ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAlumno.json");
            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            //convertimos la lista de json a lista 'Alumno'
            List<DatosAlumno> listaDatos = JsonSerializer.Deserialize<List<DatosAlumno>>(jsonString, opciones)!;

            //Creamos un nuevo objeto alumno
            DatosAlumno nuevoAlumno = new DatosAlumno();

            nuevoAlumno.Ci = TBXCI.Text;
            nuevoAlumno.nombre = TBXNAME.Text;
            nuevoAlumno.apellido = TBXAPE.Text;
            nuevoAlumno.matricula = TBXMAT.Text;
            nuevoAlumno.carrera = TBXCARRERA.Text;
            nuevoAlumno.Pass = TBXCONTRASEÑA.Text;
            nuevoAlumno.CAE = TBXCAE.Text;

            //Agregamos el nuevo objeto a la lista
            listaDatos.Add(nuevoAlumno);

            //convertimos la lista a un string con formato lista json
            string nuevaJsonString = JsonSerializer.Serialize(listaDatos);

            //limpiamos la tabla
            DGVALUMNOS.Rows.Clear();

            //escribimos en el archivo json
            File.WriteAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAlumno.json", nuevaJsonString);


            actualizarLista();

        }

        private void BTNELIMINAR_Click(object sender, EventArgs e)
        {//Json a string
            string jsonString = File.ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAlumno.json");

            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            //string a lista docente
            List<DatosAlumno> listaDatos = JsonSerializer.Deserialize<List<DatosAlumno>>(jsonString, opciones)!;

            //si un elemento de la lista tiene el id especificado lo remueve de la lista
            string n = TBXCI.Text.Trim();

            listaDatos.RemoveAll(e => e.Ci == n);

            //lista con el alumno borrado a string json
            string nuevaJsonString = JsonSerializer.Serialize(listaDatos);

            //se escribe de nuevo el archivo json con el elemento removido
            File.WriteAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAlumno.json", nuevaJsonString);
            //limpiamos la tabla
            DGVALUMNOS.Rows.Clear();


            actualizarLista();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            TBXCI.Clear();
            TBXMAT.Clear();
            TBXNAME.Clear();
            TBXCARRERA.Clear();
            TBXAPE.Clear();
            TBXMatriculaEliminar.Clear();
            TBXCONTRASEÑA.Clear();
            TBXCAE.Clear();
        }

        private void BtnAtras_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Alumno = new AdminFunciones();
            Alumno.Show();
        }

    }
}
