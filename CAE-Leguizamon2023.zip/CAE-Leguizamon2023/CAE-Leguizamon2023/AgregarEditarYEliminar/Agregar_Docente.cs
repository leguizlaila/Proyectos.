﻿using CAE_Leguizamon2023.Funciones.Alumno;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using CAE_Leguizamon2023.Funciones.Administrador;
using CAE_Leguizamon2023.Funciones.Docente;

namespace CAE_Leguizamon2023.Funciones.Administrador
{
    public partial class Agregar_Docente : Form
    {
        public Agregar_Docente()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void BTN_Retroceder_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form Docente = new AdminFunciones();
            Docente.Show();
        }
        private void Agregar_Docente_Load(object sender, EventArgs e)
        {
            actualizarLista();

        }

        public void actualizarLista()
        {
            //leer el archivo y guardar como cadena
            string jsonString = File.ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaDocente.json");

            //parametros para deserializar
            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            //deserializamos y guardamos como lista de 'Docentes'
            List<DatosDocente> listaDatos = JsonSerializer.Deserialize<List<DatosDocente>>(jsonString, opciones)!;

            //Agregamos cada elemento de la lista a la tabla
            foreach (DatosDocente docente in listaDatos)
            {
                DGVDOCENTES.Rows.Add
                    (docente.Ci, docente.nombre, docente.apellido, docente.materia, docente.Pass);
            }
        }
        private void BTNAGREGAR_Click(object sender, EventArgs e)
        {
            //leemos el archivo y guardamos como cadena
            string jsonString = File.ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaDocente.json");
            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            //convertimos la lista de json a lista 'Docente'
            List<DatosDocente> listaDatos = JsonSerializer.Deserialize<List<DatosDocente>>(jsonString, opciones)!;

            //Creamos un nuevo objeto alumno
            DatosDocente nuevoDocente = new DatosDocente();

            nuevoDocente.Ci = TXB_CI.Text;//DGVALUMNOS.Rows.Count + 1;
            nuevoDocente.nombre = TXB_NOMBRE.Text;
            nuevoDocente.apellido = TXB_APELLIDO.Text;
            nuevoDocente.materia = TXB_MATERIA.Text;
            nuevoDocente.Pass = TXB_CONTRASEÑA.Text;

            //Agregamos el nuevo objeto a la lista
            listaDatos.Add(nuevoDocente);

            //convertimos la lista a un string con formato lista json
            string nuevaJsonString = JsonSerializer.Serialize(listaDatos);

            //limpiamos la tabla
            DGVDOCENTES.Rows.Clear();

            //escribimos en el archivo json
            File.WriteAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaDocente.json", nuevaJsonString);


            actualizarLista();
        }

        private void BTN_Eliminar_Click(object sender, EventArgs e)
        {
            //Json a string
            string jsonString = File.ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaDocente.json");

            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            //string a lista docente
            List<DatosDocente> listaDatos = JsonSerializer.Deserialize<List<DatosDocente>>(jsonString, opciones)!;

            //si un elemento de la lista tiene el id especificado lo remueve de la lista
            string n = TXB_CI.Text.Trim();

            listaDatos.RemoveAll(e => e.Ci == n);

            //lista con el alumno borrado a string json
            string nuevaJsonString = JsonSerializer.Serialize(listaDatos);

            //se escribe de nuevo el archivo json con el elemento removido
            File.WriteAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaDocente.json", nuevaJsonString);
            //limpiamos la tabla
            DGVDOCENTES.Rows.Clear();


            actualizarLista();
        }

        private void BTN_Limpiar_Click(object sender, EventArgs e)
        {
            TXB_CI.Clear();
            TXB_MATERIA.Clear();
            TXB_NOMBRE.Clear();
            TXB_APELLIDO.Clear();
            TXB_CONTRASEÑA.Clear();
            TXB_CIELIMINAR.Clear();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
