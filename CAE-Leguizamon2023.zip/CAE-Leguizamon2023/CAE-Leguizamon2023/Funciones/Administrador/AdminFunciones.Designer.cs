﻿namespace CAE_Leguizamon2023.Funciones.Administrador
{
    partial class AdminFunciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            lbVer = new Label();
            btListaAlumnos = new Button();
            BtListaDocentes = new Button();
            label1 = new Label();
            lbAgregar = new Label();
            NuevoAlumno = new Button();
            NuevoDocente = new Button();
            BtAgregarAdmin = new Button();
            btListaAdmin = new Button();
            BtRetroceder = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(145, 49);
            button1.Name = "button1";
            button1.Size = new Size(168, 25);
            button1.TabIndex = 0;
            button1.Text = "REGLAMENTO";
            button1.UseVisualStyleBackColor = true;
            button1.Click += Btn_Reglamento;
            // 
            // lbVer
            // 
            lbVer.AutoSize = true;
            lbVer.Location = new Point(74, 32);
            lbVer.Name = "lbVer";
            lbVer.Size = new Size(26, 15);
            lbVer.TabIndex = 1;
            lbVer.Text = "Ver:";
            // 
            // btListaAlumnos
            // 
            btListaAlumnos.Location = new Point(145, 80);
            btListaAlumnos.Name = "btListaAlumnos";
            btListaAlumnos.Size = new Size(168, 25);
            btListaAlumnos.TabIndex = 2;
            btListaAlumnos.Text = "LISTA DE ALUMNOS";
            btListaAlumnos.UseVisualStyleBackColor = true;
            btListaAlumnos.Click += btListaAlumnos_Click;
            // 
            // BtListaDocentes
            // 
            BtListaDocentes.Location = new Point(145, 111);
            BtListaDocentes.Name = "BtListaDocentes";
            BtListaDocentes.Size = new Size(168, 25);
            BtListaDocentes.TabIndex = 3;
            BtListaDocentes.Text = "LISTA DE DOCENTES";
            BtListaDocentes.UseVisualStyleBackColor = true;
            BtListaDocentes.Click += BtListaDocentes_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(188, 290);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 4;
            // 
            // lbAgregar
            // 
            lbAgregar.AutoSize = true;
            lbAgregar.Location = new Point(2, 205);
            lbAgregar.Name = "lbAgregar";
            lbAgregar.Size = new Size(106, 15);
            lbAgregar.TabIndex = 5;
            lbAgregar.Text = "Agregar  - Eliminar";
            // 
            // NuevoAlumno
            // 
            NuevoAlumno.Location = new Point(145, 223);
            NuevoAlumno.Name = "NuevoAlumno";
            NuevoAlumno.Size = new Size(168, 25);
            NuevoAlumno.TabIndex = 7;
            NuevoAlumno.Text = "ALUMNO";
            NuevoAlumno.UseVisualStyleBackColor = true;
            NuevoAlumno.Click += NuevoAlumno_Click;
            // 
            // NuevoDocente
            // 
            NuevoDocente.Location = new Point(145, 254);
            NuevoDocente.Name = "NuevoDocente";
            NuevoDocente.Size = new Size(168, 25);
            NuevoDocente.TabIndex = 8;
            NuevoDocente.Text = "DOCENTE";
            NuevoDocente.UseVisualStyleBackColor = true;
            NuevoDocente.Click += NuevoDocente_Click;
            // 
            // BtAgregarAdmin
            // 
            BtAgregarAdmin.Location = new Point(145, 285);
            BtAgregarAdmin.Name = "BtAgregarAdmin";
            BtAgregarAdmin.Size = new Size(168, 25);
            BtAgregarAdmin.TabIndex = 14;
            BtAgregarAdmin.Text = "ADMINISTRADOR";
            BtAgregarAdmin.UseVisualStyleBackColor = true;
            BtAgregarAdmin.Click += BtAgregarAdmin_Click;
            // 
            // btListaAdmin
            // 
            btListaAdmin.Location = new Point(145, 142);
            btListaAdmin.Name = "btListaAdmin";
            btListaAdmin.Size = new Size(168, 25);
            btListaAdmin.TabIndex = 15;
            btListaAdmin.Text = "LISTA DE ADMINISTRADORES";
            btListaAdmin.UseVisualStyleBackColor = true;
            btListaAdmin.Click += btListaAdmin_Click;
            // 
            // BtRetroceder
            // 
            BtRetroceder.Location = new Point(362, 327);
            BtRetroceder.Name = "BtRetroceder";
            BtRetroceder.Size = new Size(120, 38);
            BtRetroceder.TabIndex = 23;
            BtRetroceder.Text = "Volver a Inicio";
            BtRetroceder.UseVisualStyleBackColor = true;
            BtRetroceder.Click += BtRetroceder_Click;
            // 
            // AdminFunciones
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(492, 375);
            Controls.Add(BtRetroceder);
            Controls.Add(btListaAdmin);
            Controls.Add(BtAgregarAdmin);
            Controls.Add(NuevoDocente);
            Controls.Add(NuevoAlumno);
            Controls.Add(lbAgregar);
            Controls.Add(label1);
            Controls.Add(BtListaDocentes);
            Controls.Add(btListaAlumnos);
            Controls.Add(lbVer);
            Controls.Add(button1);
            Name = "AdminFunciones";
            Text = "Administrador";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label lbVer;
        private Button btListaAlumnos;
        private Button BtListaDocentes;
        private Label label1;
        private Label lbAgregar;
        private Button NuevoAlumno;
        private Button NuevoDocente;
        private Button BtAgregarAdmin;
        private Button btListaAdmin;
        private Button BtRetroceder;
    }
}