﻿using CAE_Leguizamon2023.AgregarEditarYEliminar;
using CAE_Leguizamon2023.Funciones.Alumno.AgregarEditarYEliminar;
using CAE_Leguizamon2023.Mostrar;
using CAE_Leguizamon2023.Login.c;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAE_Leguizamon2023.Funciones.Administrador
{
    public partial class AdminFunciones : Form
    {
        public AdminFunciones()
        {
            InitializeComponent();
        }

        private void Btn_Reglamento(object sender, EventArgs e)
        {
            this.Hide();
            Form VentCAE = new ReglamentoCAE();
            VentCAE.Show();
        }

        private void BtRetroceder_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Home1 = new Home(); // Crea una instancia del formulario anterior
            Home1.Show(); // Muestra el formulario anterior
        }

        private void NuevoAlumno_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form AgregarAlumno = new Agregar_Alumno();
            AgregarAlumno.Show();
        }

        private void NuevoDocente_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form AgregarDocente = new Agregar_Docente();
            AgregarDocente.Show();
        }

        private void BtAgregarAdmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form AgregarNuevoAdmin = new Agregar_Administrador();
            AgregarNuevoAdmin.Show();
        }

        private void btListaAlumnos_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ListaAlumnos = new Alumnos();
            ListaAlumnos.Show();
        }

        private void BtListaDocentes_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ListaDocentes = new Docentes();
            ListaDocentes.Show();
        }

        private void btListaAdmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ListaAdmin = new Admin();
            ListaAdmin.Show();
        }
    }
}
