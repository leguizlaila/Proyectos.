﻿namespace CAE_Leguizamon2023.Funciones.Alumno
{
    partial class Funciones_Alumno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbVerA = new Label();
            BtReglamentoAlumno = new Button();
            BtVerCaeAcumulado = new Button();
            label1 = new Label();
            BtSolicitarReunion = new Button();
            BtActualizacionCAE = new Button();
            lbImprimir = new Label();
            BtPlanillaCAE = new Button();
            BtVolverInicio = new Button();
            SuspendLayout();
            // 
            // lbVerA
            // 
            lbVerA.AutoSize = true;
            lbVerA.Location = new Point(53, 44);
            lbVerA.Name = "lbVerA";
            lbVerA.Size = new Size(26, 15);
            lbVerA.TabIndex = 0;
            lbVerA.Text = "Ver:";
            // 
            // BtReglamentoAlumno
            // 
            BtReglamentoAlumno.Location = new Point(116, 64);
            BtReglamentoAlumno.Name = "BtReglamentoAlumno";
            BtReglamentoAlumno.Size = new Size(209, 29);
            BtReglamentoAlumno.TabIndex = 1;
            BtReglamentoAlumno.Text = "REGLAMENTO";
            BtReglamentoAlumno.UseVisualStyleBackColor = true;
            BtReglamentoAlumno.Click += BtReglamentoAlumno_Click;
            // 
            // BtVerCaeAcumulado
            // 
            BtVerCaeAcumulado.Location = new Point(116, 98);
            BtVerCaeAcumulado.Name = "BtVerCaeAcumulado";
            BtVerCaeAcumulado.Size = new Size(209, 29);
            BtVerCaeAcumulado.TabIndex = 2;
            BtVerCaeAcumulado.Text = "HORAS DE CAE ACUMULADAS";
            BtVerCaeAcumulado.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(53, 191);
            label1.Name = "label1";
            label1.Size = new Size(52, 15);
            label1.TabIndex = 3;
            label1.Text = "Solicitar:";
            // 
            // BtSolicitarReunion
            // 
            BtSolicitarReunion.Location = new Point(116, 202);
            BtSolicitarReunion.Name = "BtSolicitarReunion";
            BtSolicitarReunion.Size = new Size(209, 29);
            BtSolicitarReunion.TabIndex = 4;
            BtSolicitarReunion.Text = "REUNION CON EL COORDINADOR";
            BtSolicitarReunion.UseVisualStyleBackColor = true;
            // 
            // BtActualizacionCAE
            // 
            BtActualizacionCAE.Location = new Point(116, 237);
            BtActualizacionCAE.Name = "BtActualizacionCAE";
            BtActualizacionCAE.Size = new Size(209, 29);
            BtActualizacionCAE.TabIndex = 5;
            BtActualizacionCAE.Text = "ACTUALIZACION DE HORAS CAE";
            BtActualizacionCAE.UseVisualStyleBackColor = true;
            // 
            // lbImprimir
            // 
            lbImprimir.AutoSize = true;
            lbImprimir.Location = new Point(53, 311);
            lbImprimir.Name = "lbImprimir";
            lbImprimir.Size = new Size(56, 15);
            lbImprimir.TabIndex = 6;
            lbImprimir.Text = "Imprimir:";
            // 
            // BtPlanillaCAE
            // 
            BtPlanillaCAE.Location = new Point(116, 328);
            BtPlanillaCAE.Name = "BtPlanillaCAE";
            BtPlanillaCAE.Size = new Size(209, 29);
            BtPlanillaCAE.TabIndex = 7;
            BtPlanillaCAE.Text = "PLANILLA DE CAE ";
            BtPlanillaCAE.UseVisualStyleBackColor = true;
            // 
            // BtVolverInicio
            // 
            BtVolverInicio.Location = new Point(415, 391);
            BtVolverInicio.Name = "BtVolverInicio";
            BtVolverInicio.Size = new Size(122, 32);
            BtVolverInicio.TabIndex = 8;
            BtVolverInicio.Text = "Volver a Inicio";
            BtVolverInicio.UseVisualStyleBackColor = true;
            BtVolverInicio.Click += BtVolverInicio_Click;
            // 
            // Funciones_Alumno
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(549, 439);
            Controls.Add(BtVolverInicio);
            Controls.Add(BtPlanillaCAE);
            Controls.Add(lbImprimir);
            Controls.Add(BtActualizacionCAE);
            Controls.Add(BtSolicitarReunion);
            Controls.Add(label1);
            Controls.Add(BtVerCaeAcumulado);
            Controls.Add(BtReglamentoAlumno);
            Controls.Add(lbVerA);
            Name = "Funciones_Alumno";
            Text = "Funciones_Alumno";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbVerA;
        private Button BtReglamentoAlumno;
        private Button BtVerCaeAcumulado;
        private Label label1;
        private Button BtSolicitarReunion;
        private Button BtActualizacionCAE;
        private Label lbImprimir;
        private Button BtPlanillaCAE;
        private Button BtVolverInicio;
    }
}