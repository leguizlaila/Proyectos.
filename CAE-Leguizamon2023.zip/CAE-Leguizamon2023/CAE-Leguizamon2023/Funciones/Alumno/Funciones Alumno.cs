﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CAE_Leguizamon2023;

namespace CAE_Leguizamon2023.Funciones.Alumno
{
    public partial class Funciones_Alumno : Form
    {
        public Funciones_Alumno()
        {
            InitializeComponent();
        }

        private void BtVolverInicio_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Home2 = new Home(); // Crea una instancia del formulario anterior
            Home2.Show(); // Muestra el formulario anterior
        }

        private void BtReglamentoAlumno_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Reglamento = new ReglamentoCAEAlumnos(); // Crea una instancia del formulario anterior
            Reglamento.Show(); // Muestra el formulario anterior
        }
    }
}
