﻿using CAE_Leguizamon2023.Mostrar;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAE_Leguizamon2023.Funciones.Docente
{
    public partial class Funciones_Docente : Form
    {
        public Funciones_Docente()
        {
            InitializeComponent();
        }

        private void BtVolverInicioDocente_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Home3 = new Home(); // Crea una instancia del formulario anterior
            Home3.Show(); // Muestra el formulario anterior
        }

        private void BtListaAlumnosDocente_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ListaAlumnos = new AlumnosDocente();
            ListaAlumnos.Show();
        }

        private void BtReglamentoDocente_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form ListaAlumnos = new ReglamentoCAEDocentes();
            ListaAlumnos.Show();
        }
    }
}
