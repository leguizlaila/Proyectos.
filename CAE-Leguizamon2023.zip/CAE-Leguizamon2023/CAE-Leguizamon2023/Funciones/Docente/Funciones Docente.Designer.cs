﻿namespace CAE_Leguizamon2023.Funciones.Docente
{
    partial class Funciones_Docente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LbVerDocente = new Label();
            BtReglamentoDocente = new Button();
            BtListaAlumnosDocente = new Button();
            LbImprimirSAyundatia = new Label();
            BtNotaAyudantia = new Button();
            LbVerificarDocAyudantia = new Label();
            VerificarAyudantia = new Button();
            BtVolverInicioDocente = new Button();
            SuspendLayout();
            // 
            // LbVerDocente
            // 
            LbVerDocente.AutoSize = true;
            LbVerDocente.Location = new Point(40, 36);
            LbVerDocente.Name = "LbVerDocente";
            LbVerDocente.Size = new Size(26, 15);
            LbVerDocente.TabIndex = 0;
            LbVerDocente.Text = "Ver:";
            // 
            // BtReglamentoDocente
            // 
            BtReglamentoDocente.Location = new Point(94, 48);
            BtReglamentoDocente.Name = "BtReglamentoDocente";
            BtReglamentoDocente.Size = new Size(171, 30);
            BtReglamentoDocente.TabIndex = 1;
            BtReglamentoDocente.Text = "REGLAMENTO";
            BtReglamentoDocente.UseVisualStyleBackColor = true;
            BtReglamentoDocente.Click += BtReglamentoDocente_Click;
            // 
            // BtListaAlumnosDocente
            // 
            BtListaAlumnosDocente.Location = new Point(94, 84);
            BtListaAlumnosDocente.Name = "BtListaAlumnosDocente";
            BtListaAlumnosDocente.Size = new Size(171, 30);
            BtListaAlumnosDocente.TabIndex = 2;
            BtListaAlumnosDocente.Text = "LISTA DE ALUMNOS";
            BtListaAlumnosDocente.UseVisualStyleBackColor = true;
            BtListaAlumnosDocente.Click += BtListaAlumnosDocente_Click;
            // 
            // LbImprimirSAyundatia
            // 
            LbImprimirSAyundatia.AutoSize = true;
            LbImprimirSAyundatia.Location = new Point(42, 163);
            LbImprimirSAyundatia.Name = "LbImprimirSAyundatia";
            LbImprimirSAyundatia.Size = new Size(56, 15);
            LbImprimirSAyundatia.TabIndex = 3;
            LbImprimirSAyundatia.Text = "Imprimir:";
            // 
            // BtNotaAyudantia
            // 
            BtNotaAyudantia.Location = new Point(94, 181);
            BtNotaAyudantia.Name = "BtNotaAyudantia";
            BtNotaAyudantia.Size = new Size(210, 29);
            BtNotaAyudantia.TabIndex = 4;
            BtNotaAyudantia.Text = "NOTA DE SOLICITUD DE AYUDANTIA";
            BtNotaAyudantia.UseVisualStyleBackColor = true;
            // 
            // LbVerificarDocAyudantia
            // 
            LbVerificarDocAyudantia.AutoSize = true;
            LbVerificarDocAyudantia.Location = new Point(46, 259);
            LbVerificarDocAyudantia.Name = "LbVerificarDocAyudantia";
            LbVerificarDocAyudantia.Size = new Size(52, 15);
            LbVerificarDocAyudantia.TabIndex = 5;
            LbVerificarDocAyudantia.Text = "Verificar:";
            // 
            // VerificarAyudantia
            // 
            VerificarAyudantia.Location = new Point(94, 287);
            VerificarAyudantia.Name = "VerificarAyudantia";
            VerificarAyudantia.Size = new Size(210, 29);
            VerificarAyudantia.TabIndex = 6;
            VerificarAyudantia.Text = "HORAS DE AYUDANTIA";
            VerificarAyudantia.UseVisualStyleBackColor = true;
            // 
            // BtVolverInicioDocente
            // 
            BtVolverInicioDocente.Location = new Point(405, 370);
            BtVolverInicioDocente.Name = "BtVolverInicioDocente";
            BtVolverInicioDocente.Size = new Size(103, 32);
            BtVolverInicioDocente.TabIndex = 7;
            BtVolverInicioDocente.Text = "Volver a Inicio";
            BtVolverInicioDocente.UseVisualStyleBackColor = true;
            BtVolverInicioDocente.Click += BtVolverInicioDocente_Click;
            // 
            // Funciones_Docente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(564, 450);
            Controls.Add(BtVolverInicioDocente);
            Controls.Add(VerificarAyudantia);
            Controls.Add(LbVerificarDocAyudantia);
            Controls.Add(BtNotaAyudantia);
            Controls.Add(LbImprimirSAyundatia);
            Controls.Add(BtListaAlumnosDocente);
            Controls.Add(BtReglamentoDocente);
            Controls.Add(LbVerDocente);
            Name = "Funciones_Docente";
            Text = "Funciones_Docente";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LbVerDocente;
        private Button BtReglamentoDocente;
        private Button BtListaAlumnosDocente;
        private Label LbImprimirSAyundatia;
        private Button BtNotaAyudantia;
        private Label LbVerificarDocAyudantia;
        private Button VerificarAyudantia;
        private Button BtVolverInicioDocente;
    }
}