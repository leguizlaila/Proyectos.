﻿namespace CAE_Leguizamon2023.Login.c
{
    partial class LoginDocente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MensajeLogDocente = new Label();
            MensajeCIDocente = new Label();
            MensajeContraseñaDocente = new Label();
            textBoxCIDocente = new TextBox();
            textboxcontraseñaDoc = new TextBox();
            MostrarContDoc = new CheckBox();
            BotonRetrocederDoc = new Button();
            BotonIngresarDoc = new Button();
            btn_limpiar2 = new Button();
            SuspendLayout();
            // 
            // MensajeLogDocente
            // 
            MensajeLogDocente.AutoSize = true;
            MensajeLogDocente.Location = new Point(114, 88);
            MensajeLogDocente.Name = "MensajeLogDocente";
            MensajeLogDocente.Size = new Size(63, 15);
            MensajeLogDocente.TabIndex = 3;
            MensajeLogDocente.Text = "Ingrese su:";
            // 
            // MensajeCIDocente
            // 
            MensajeCIDocente.AutoSize = true;
            MensajeCIDocente.Location = new Point(96, 160);
            MensajeCIDocente.Name = "MensajeCIDocente";
            MensajeCIDocente.Size = new Size(24, 15);
            MensajeCIDocente.TabIndex = 5;
            MensajeCIDocente.Text = "C.I:";
            // 
            // MensajeContraseñaDocente
            // 
            MensajeContraseñaDocente.AutoSize = true;
            MensajeContraseñaDocente.Location = new Point(96, 250);
            MensajeContraseñaDocente.Name = "MensajeContraseñaDocente";
            MensajeContraseñaDocente.Size = new Size(70, 15);
            MensajeContraseñaDocente.TabIndex = 6;
            MensajeContraseñaDocente.Text = "Contraseña:";
            // 
            // textBoxCIDocente
            // 
            textBoxCIDocente.Location = new Point(205, 160);
            textBoxCIDocente.Name = "textBoxCIDocente";
            textBoxCIDocente.Size = new Size(154, 23);
            textBoxCIDocente.TabIndex = 7;
            // 
            // textboxcontraseñaDoc
            // 
            textboxcontraseñaDoc.Location = new Point(205, 242);
            textboxcontraseñaDoc.Name = "textboxcontraseñaDoc";
            textboxcontraseñaDoc.PasswordChar = '*';
            textboxcontraseñaDoc.Size = new Size(154, 23);
            textboxcontraseñaDoc.TabIndex = 8;
            textboxcontraseñaDoc.TextChanged += textBox2_TextChanged;
            // 
            // MostrarContDoc
            // 
            MostrarContDoc.AutoSize = true;
            MostrarContDoc.Location = new Point(389, 244);
            MostrarContDoc.Name = "MostrarContDoc";
            MostrarContDoc.Size = new Size(128, 19);
            MostrarContDoc.TabIndex = 9;
            MostrarContDoc.Text = "Mostrar contraseña";
            MostrarContDoc.UseVisualStyleBackColor = true;
            MostrarContDoc.CheckedChanged += MostrarContDoc_CheckedChanged;
            // 
            // BotonRetrocederDoc
            // 
            BotonRetrocederDoc.Location = new Point(96, 352);
            BotonRetrocederDoc.Name = "BotonRetrocederDoc";
            BotonRetrocederDoc.Size = new Size(137, 44);
            BotonRetrocederDoc.TabIndex = 10;
            BotonRetrocederDoc.Text = "Atrás";
            BotonRetrocederDoc.UseVisualStyleBackColor = true;
            BotonRetrocederDoc.Click += BotonRetrocederDoc_Click;
            // 
            // BotonIngresarDoc
            // 
            BotonIngresarDoc.Location = new Point(315, 352);
            BotonIngresarDoc.Name = "BotonIngresarDoc";
            BotonIngresarDoc.Size = new Size(137, 44);
            BotonIngresarDoc.TabIndex = 11;
            BotonIngresarDoc.Text = "Ingresar";
            BotonIngresarDoc.UseVisualStyleBackColor = true;
            BotonIngresarDoc.Click += BotonIngresarDoc_Click;
            // 
            // btn_limpiar2
            // 
            btn_limpiar2.Location = new Point(417, 215);
            btn_limpiar2.Name = "btn_limpiar2";
            btn_limpiar2.Size = new Size(75, 23);
            btn_limpiar2.TabIndex = 12;
            btn_limpiar2.Text = "Limpiar";
            btn_limpiar2.UseVisualStyleBackColor = true;
            btn_limpiar2.Click += btn_limpiar2_Click;
            // 
            // LoginDocente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(564, 450);
            Controls.Add(btn_limpiar2);
            Controls.Add(BotonIngresarDoc);
            Controls.Add(BotonRetrocederDoc);
            Controls.Add(MostrarContDoc);
            Controls.Add(textboxcontraseñaDoc);
            Controls.Add(textBoxCIDocente);
            Controls.Add(MensajeContraseñaDocente);
            Controls.Add(MensajeCIDocente);
            Controls.Add(MensajeLogDocente);
            Name = "LoginDocente";
            Text = "LoginDocente";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label MensajeLogDocente;
        private Label MensajeCIDocente;
        private Label MensajeContraseñaDocente;
        private TextBox textBoxCIDocente;
        private TextBox textboxcontraseñaDoc;
        private CheckBox MostrarContDoc;
        private Button BotonRetrocederDoc;
        private Button BotonIngresarDoc;
        private Button btn_limpiar2;
    }
}