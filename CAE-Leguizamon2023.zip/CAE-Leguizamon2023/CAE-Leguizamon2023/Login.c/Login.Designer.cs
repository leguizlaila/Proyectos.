﻿namespace CAE_Leguizamon2023.Login.c
{
    partial class VentanaLogAd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BotonRetroceder = new Button();
            BotonIngresar = new Button();
            MensajeLog = new Label();
            txbCi = new TextBox();
            MensajeCI = new Label();
            label3 = new Label();
            txbCont = new TextBox();
            MostrarCont = new CheckBox();
            btn_limpiar = new Button();
            SuspendLayout();
            // 
            // BotonRetroceder
            // 
            BotonRetroceder.Location = new Point(96, 329);
            BotonRetroceder.Name = "BotonRetroceder";
            BotonRetroceder.Size = new Size(137, 36);
            BotonRetroceder.TabIndex = 0;
            BotonRetroceder.Text = "Atrás";
            BotonRetroceder.UseVisualStyleBackColor = true;
            BotonRetroceder.Click += BotonRetroceder_Click;
            // 
            // BotonIngresar
            // 
            BotonIngresar.Location = new Point(319, 329);
            BotonIngresar.Name = "BotonIngresar";
            BotonIngresar.Size = new Size(128, 36);
            BotonIngresar.TabIndex = 1;
            BotonIngresar.Text = "Ingresar";
            BotonIngresar.UseVisualStyleBackColor = true;
            BotonIngresar.Click += BotonIngresar_Click;
            // 
            // MensajeLog
            // 
            MensajeLog.AutoSize = true;
            MensajeLog.Location = new Point(107, 75);
            MensajeLog.Name = "MensajeLog";
            MensajeLog.Size = new Size(63, 15);
            MensajeLog.TabIndex = 2;
            MensajeLog.Text = "Ingrese su:";
            // 
            // txbCi
            // 
            txbCi.Location = new Point(209, 139);
            txbCi.Name = "txbCi";
            txbCi.Size = new Size(154, 23);
            txbCi.TabIndex = 3;
            txbCi.TextChanged += textBox1_TextChanged;
            // 
            // MensajeCI
            // 
            MensajeCI.AutoSize = true;
            MensajeCI.Location = new Point(96, 139);
            MensajeCI.Name = "MensajeCI";
            MensajeCI.Size = new Size(24, 15);
            MensajeCI.TabIndex = 4;
            MensajeCI.Text = "C.I:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(100, 223);
            label3.Name = "label3";
            label3.Size = new Size(70, 15);
            label3.TabIndex = 5;
            label3.Text = "Contraseña:";
            // 
            // txbCont
            // 
            txbCont.Location = new Point(209, 215);
            txbCont.Name = "txbCont";
            txbCont.PasswordChar = '*';
            txbCont.Size = new Size(154, 23);
            txbCont.TabIndex = 6;
            // 
            // MostrarCont
            // 
            MostrarCont.AutoSize = true;
            MostrarCont.Location = new Point(412, 218);
            MostrarCont.Name = "MostrarCont";
            MostrarCont.Size = new Size(128, 19);
            MostrarCont.TabIndex = 7;
            MostrarCont.Text = "Mostrar contraseña";
            MostrarCont.UseVisualStyleBackColor = true;
            MostrarCont.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // btn_limpiar
            // 
            btn_limpiar.Location = new Point(439, 189);
            btn_limpiar.Name = "btn_limpiar";
            btn_limpiar.Size = new Size(75, 23);
            btn_limpiar.TabIndex = 8;
            btn_limpiar.Text = "Limpiar";
            btn_limpiar.UseVisualStyleBackColor = true;
            btn_limpiar.Click += btn_limpiar_Click;
            // 
            // VentanaLogAd
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(564, 450);
            Controls.Add(btn_limpiar);
            Controls.Add(MostrarCont);
            Controls.Add(txbCont);
            Controls.Add(label3);
            Controls.Add(MensajeCI);
            Controls.Add(txbCi);
            Controls.Add(MensajeLog);
            Controls.Add(BotonIngresar);
            Controls.Add(BotonRetroceder);
            Name = "VentanaLogAd";
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion


        private TextBox txt_Ci;
        private TextBox txt_Pass;
        private TextBox txt_nombre;
        private TextBox txt_apellido;
        private Button BotonRetroceder;
        private Button BotonIngresar;
        private Label MensajeLog;
        private TextBox txbCi;
        private Label MensajeCI;
        private Label label3;
        private TextBox txbCont;
        private CheckBox MostrarCont;
        private Button btn_limpiar;
    }
}