﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using CAE_Leguizamon2023.Funciones.Administrador;


namespace CAE_Leguizamon2023.Login.c
{
    public partial class VentanaLogAd : Form
    {

        public VentanaLogAd()
        {
            InitializeComponent();
        
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //  this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (MostrarCont.Checked == true)
            {
                if (txbCont.PasswordChar == '*')
                {
                    txbCont.PasswordChar = '\0';
                }

            }

            else
            {
                txbCont.PasswordChar = '*';
            }
        }

        private void BotonRetroceder_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Home = new Home(); // Crea una instancia del formulario anterior
            Home.Show(); // Muestra el formulario anterior
        }

        private void BotonIngresar_Click(object sender, EventArgs e)
        {
           // leemos el archivo json y almacenamos en un string
            string jsonString =
            File
            .ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAdmin.json");
            //configuramos las opciones
            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            //creamos la lista con usuarios
            List<DatosAlumno> listaUsuarios =
            JsonSerializer
            .Deserialize<List<DatosAlumno>>(jsonString, opciones)!;
            string ci = txbCi.Text.Trim();
            string pass = txbCont.Text.Trim();

            if (comprobar(listaUsuarios, ci, pass))
            {
                this.Hide();
                Form VenAdmin = new AdminFunciones();
                VenAdmin.Show();
            }
            else
            {
                MessageBox.Show("Ci o contraseña incorrecta");
            }

        }

        private bool comprobar(List<DatosAlumno> lista, string ci, string pass)
        {
            bool retorno = false;

            foreach (var item in lista)
            {
                if (item.Ci == ci && item.Pass == pass)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        
        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            txbCi.Clear();
            txbCont.Clear();
        }


    }
}
