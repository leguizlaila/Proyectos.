﻿namespace CAE_Leguizamon2023.Login.c
{
    partial class LoginAlumno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            MensajeLogAl = new Label();
            labelIngresesu = new Label();
            labelContraseña = new Label();
            textBoxContraseñaAl = new TextBox();
            textboxCI = new TextBox();
            MostrarContAl = new CheckBox();
            BotonRetrocederAl = new Button();
            BotonIngresarAl = new Button();
            btn_limpiar1 = new Button();
            SuspendLayout();
            // 
            // MensajeLogAl
            // 
            MensajeLogAl.AutoSize = true;
            MensajeLogAl.Location = new Point(86, 174);
            MensajeLogAl.Name = "MensajeLogAl";
            MensajeLogAl.Size = new Size(24, 15);
            MensajeLogAl.TabIndex = 4;
            MensajeLogAl.Text = "C.I:";
            // 
            // labelIngresesu
            // 
            labelIngresesu.AutoSize = true;
            labelIngresesu.Location = new Point(108, 87);
            labelIngresesu.Name = "labelIngresesu";
            labelIngresesu.Size = new Size(63, 15);
            labelIngresesu.TabIndex = 5;
            labelIngresesu.Text = "Ingrese su:";
            // 
            // labelContraseña
            // 
            labelContraseña.AutoSize = true;
            labelContraseña.Location = new Point(86, 256);
            labelContraseña.Name = "labelContraseña";
            labelContraseña.Size = new Size(70, 15);
            labelContraseña.TabIndex = 6;
            labelContraseña.Text = "Contraseña:";
            // 
            // textBoxContraseñaAl
            // 
            textBoxContraseñaAl.Location = new Point(205, 251);
            textBoxContraseñaAl.Name = "textBoxContraseñaAl";
            textBoxContraseñaAl.PasswordChar = '*';
            textBoxContraseñaAl.Size = new Size(154, 23);
            textBoxContraseñaAl.TabIndex = 8;
            textBoxContraseñaAl.TextChanged += textBoxContraseñaAl_TextChanged;
            // 
            // textboxCI
            // 
            textboxCI.Location = new Point(205, 171);
            textboxCI.Name = "textboxCI";
            textboxCI.Size = new Size(154, 23);
            textboxCI.TabIndex = 9;
            // 
            // MostrarContAl
            // 
            MostrarContAl.AutoSize = true;
            MostrarContAl.Location = new Point(403, 253);
            MostrarContAl.Name = "MostrarContAl";
            MostrarContAl.Size = new Size(128, 19);
            MostrarContAl.TabIndex = 10;
            MostrarContAl.Text = "Mostrar contraseña";
            MostrarContAl.UseVisualStyleBackColor = true;
            MostrarContAl.CheckedChanged += MostrarContAl_CheckedChanged;
            // 
            // BotonRetrocederAl
            // 
            BotonRetrocederAl.Location = new Point(105, 349);
            BotonRetrocederAl.Name = "BotonRetrocederAl";
            BotonRetrocederAl.Size = new Size(137, 44);
            BotonRetrocederAl.TabIndex = 11;
            BotonRetrocederAl.Text = "Atrás";
            BotonRetrocederAl.UseVisualStyleBackColor = true;
            BotonRetrocederAl.Click += BotonRetrocederAl_Click;
            // 
            // BotonIngresarAl
            // 
            BotonIngresarAl.Location = new Point(330, 349);
            BotonIngresarAl.Name = "BotonIngresarAl";
            BotonIngresarAl.Size = new Size(137, 44);
            BotonIngresarAl.TabIndex = 12;
            BotonIngresarAl.Text = "Ingresar";
            BotonIngresarAl.UseVisualStyleBackColor = true;
            BotonIngresarAl.Click += BotonIngresarAl_Click;
            // 
            // btn_limpiar1
            // 
            btn_limpiar1.Location = new Point(429, 224);
            btn_limpiar1.Name = "btn_limpiar1";
            btn_limpiar1.Size = new Size(75, 23);
            btn_limpiar1.TabIndex = 13;
            btn_limpiar1.Text = "Limpiar";
            btn_limpiar1.UseVisualStyleBackColor = true;
            btn_limpiar1.Click += btn_limpiar1_Click;
            // 
            // LoginAlumno
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(564, 450);
            Controls.Add(btn_limpiar1);
            Controls.Add(BotonIngresarAl);
            Controls.Add(BotonRetrocederAl);
            Controls.Add(MostrarContAl);
            Controls.Add(textboxCI);
            Controls.Add(textBoxContraseñaAl);
            Controls.Add(labelContraseña);
            Controls.Add(labelIngresesu);
            Controls.Add(MensajeLogAl);
            Name = "LoginAlumno";
            Text = "LoginAlumno";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label MensajeLogAl;
        private Label labelIngresesu;
        private Label labelContraseña;
        private TextBox textBoxContraseñaAl;
        private TextBox textboxCI;
        private CheckBox MostrarContAl;
        private Button BotonRetrocederAl;
        private Button BotonIngresarAl;
        private Button btn_limpiar1;
    }
}