﻿using CAE_Leguizamon2023.Funciones.Alumno;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using CAE_Leguizamon2023.Funciones.Docente;

namespace CAE_Leguizamon2023.Login.c
{
    public partial class LoginDocente : Form
    {
        public LoginDocente()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void MostrarContDoc_CheckedChanged(object sender, EventArgs e)
        {
            if (MostrarContDoc.Checked == true)
            {
                if (textboxcontraseñaDoc.PasswordChar == '*')
                {
                    textboxcontraseñaDoc.PasswordChar = '\0';
                }

            }

            else
            {
                textboxcontraseñaDoc.PasswordChar = '*';
            }
        }

        private void BotonRetrocederDoc_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Home = new Home(); // Crea una instancia del formulario anterior
            Home.Show(); // Muestra el formulario anterior
        }

        private void BotonIngresarDoc_Click(object sender, EventArgs e)
        {
            // leemos el archivo json y almacenamos en un string
            string jsonString =
            File
            .ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaDocente.json");
            //configuramos las opciones
            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            //creamos la lista con usuarios
            List<DatosAlumno> listaUsuarios =
            JsonSerializer
            .Deserialize<List<DatosAlumno>>(jsonString, opciones)!;
            string ci = textBoxCIDocente.Text.Trim();
            string pass = textboxcontraseñaDoc.Text.Trim();

            if (comprobar(listaUsuarios, ci, pass))
            {
                this.Hide();
                Form VenDoc = new Funciones_Docente();
                VenDoc.Show();
            }
            else
            {
                MessageBox.Show("Ci o contraseña incorrecta");
            }

        }

        private bool comprobar(List<DatosAlumno> lista, string ci, string pass)
        {
            bool retorno = false;

            foreach (var item in lista)
            {
                if (item.Ci == ci && item.Pass == pass)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        private void btn_limpiar2_Click(object sender, EventArgs e)
        {
            textBoxCIDocente.Clear();
            textboxcontraseñaDoc.Clear();
        }
    }
}

