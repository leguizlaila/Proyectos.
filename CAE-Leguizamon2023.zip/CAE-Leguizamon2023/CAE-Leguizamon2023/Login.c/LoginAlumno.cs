﻿using CAE_Leguizamon2023.Funciones.Administrador;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using CAE_Leguizamon2023.Funciones.Alumno;


namespace CAE_Leguizamon2023.Login.c
{
    public partial class LoginAlumno : Form
    {
        public LoginAlumno()
        {
            InitializeComponent();
        }

        private void MostrarContAl_CheckedChanged(object sender, EventArgs e)
        {

            if (MostrarContAl.Checked == true)
            {
                if (textBoxContraseñaAl.PasswordChar == '*')
                {
                    textBoxContraseñaAl.PasswordChar = '\0';
                }

            }

            else
            {
                textBoxContraseñaAl.PasswordChar = '*';
            }
        }

        private void textBoxContraseñaAl_TextChanged(object sender, EventArgs e)
        {

        }

        private void BotonRetrocederAl_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Home = new Home(); // Crea una instancia del formulario anterior
            Home.Show(); // Muestra el formulario anterior
        }

        private void BotonIngresarAl_Click(object sender, EventArgs e)
        {
            // leemos el archivo json y almacenamos en un string
            string jsonString =
            File
            .ReadAllText(@"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAlumno.json");
            //configuramos las opciones
            var opciones = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            //creamos la lista con usuarios
            List<DatosAlumno> listaUsuarios =
            JsonSerializer
            .Deserialize<List<DatosAlumno>>(jsonString, opciones)!;
            string ci = textboxCI.Text.Trim();
            string pass = textBoxContraseñaAl.Text.Trim();

            if (comprobar(listaUsuarios, ci, pass))
            {
                this.Hide();
                Form VenAlum = new Funciones_Alumno();
                VenAlum.Show();
            }
            else
            {
                MessageBox.Show("Ci o contraseña incorrecta");
            }

        }

        private bool comprobar(List<DatosAlumno> lista, string ci, string pass)
        {
            bool retorno = false;

            foreach (var item in lista)
            {
                if (item.Ci == ci && item.Pass == pass)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        private void btn_limpiar1_Click(object sender, EventArgs e)
        {
            textboxCI.Clear();
            textBoxContraseñaAl.Clear();
        }
    }
}

