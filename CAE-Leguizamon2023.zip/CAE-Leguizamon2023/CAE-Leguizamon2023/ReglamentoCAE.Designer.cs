﻿namespace CAE_Leguizamon2023
{
    partial class ReglamentoCAE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer componentes = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (componentes != null))
            {
                componentes.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReglamentoCAE));
            lbReglamento = new Label();
            BtnRetroceder = new Button();
            SuspendLayout();
            // 
            // lbReglamento
            // 
            lbReglamento.AutoSize = true;
            lbReglamento.Location = new Point(12, 3);
            lbReglamento.Name = "lbReglamento";
            lbReglamento.Size = new Size(528, 390);
            lbReglamento.TabIndex = 0;
            lbReglamento.Text = resources.GetString("lbReglamento.Text");
            lbReglamento.Click += lbReglamento_Click;
            // 
            // BtnRetroceder
            // 
            BtnRetroceder.Location = new Point(453, 396);
            BtnRetroceder.Name = "BtnRetroceder";
            BtnRetroceder.Size = new Size(87, 35);
            BtnRetroceder.TabIndex = 2;
            BtnRetroceder.Text = "Atras";
            BtnRetroceder.UseVisualStyleBackColor = true;
            BtnRetroceder.Click += BtnRetroceder_Click;
            // 
            // ReglamentoCAE
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(564, 441);
            Controls.Add(BtnRetroceder);
            Controls.Add(lbReglamento);
            Name = "ReglamentoCAE";
            Text = "Reglamento CAE";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbReglamento;
        private Button BtnRetroceder;
    }
}