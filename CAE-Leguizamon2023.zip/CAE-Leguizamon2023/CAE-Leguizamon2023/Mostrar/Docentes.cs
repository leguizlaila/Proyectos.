﻿using CAE_Leguizamon2023.Funciones.Administrador;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAE_Leguizamon2023.Mostrar
{
    public partial class Docentes : Form
    {
        public Docentes()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Docentes_Load(object sender, EventArgs e)
        {
            JsonDocente();
        }

        private void JsonDocente()
        {
            try
            {
                string ruta = @"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaDocente.json";

                // Lee el contenido del archivo JSON
                string jsonString = File.ReadAllText(ruta);

                // Deserializa el contenido JSON en una lista de 'Datos Docente'
                List<DatosDocente> listaDatos = JsonSerializer.Deserialize<List<DatosDocente>>(jsonString);

                // Limpia el DataGridView antes de agregar los datos
                DataGridListaDocentes.Rows.Clear();

                // Agrega cada elemento de la lista al DataGridView
                foreach (DatosDocente docentes in listaDatos)
                {
                    DataGridListaDocentes.Rows.Add(docentes.Ci, docentes.nombre, docentes.apellido, docentes.materia);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos JSON: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnRetroceder_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Atras = new AdminFunciones(); // Crea una instancia del formulario anterior
            Atras.Show(); // Muestra el formulario anterior
        }
    }
}

