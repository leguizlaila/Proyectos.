﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using CAE_Leguizamon2023.Funciones.Administrador;



namespace CAE_Leguizamon2023.Mostrar
{
    public partial class Alumnos : Form
    {

        public Alumnos()
        {
            InitializeComponent();
        }

        private void Alumnos_Load(object sender, EventArgs e)
        {
            ListaAlumnos();
        }

        private void ListaAlumnos()
        {
            string ruta = @"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAlumno.json";

            // Lee el contenido del archivo JSON
            string jsonString = File.ReadAllText(ruta);

            // Deserializa el contenido JSON en una lista de 'Datos Alumno'
            List<DatosAlumno> listaDatos = JsonSerializer.Deserialize<List<DatosAlumno>>(jsonString);

            // Limpia el DataGridView antes de agregar los datos
            DataGridListaAlumnos.Rows.Clear();

            // Agrega cada elemento de la lista al DataGridView
            foreach (DatosAlumno alumno in listaDatos)
            {
                DataGridListaAlumnos.Rows.Add(alumno.Ci, alumno.nombre, alumno.apellido, alumno.matricula, alumno.carrera);
            }
        }

        private void BtnRetroceder_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Atras = new AdminFunciones(); // Crea una instancia del formulario anterior
            Atras.Show(); // Muestra el formulario anterior  
        }

        private void DataGridListaAlumnos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

}
