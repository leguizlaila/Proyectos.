﻿namespace CAE_Leguizamon2023.Mostrar
{
    partial class Docentes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Button BtnRetroceder;
            DataGridListaDocentes = new DataGridView();
            CIColumna = new DataGridViewTextBoxColumn();
            NombreColumna = new DataGridViewTextBoxColumn();
            ApellidoColumna = new DataGridViewTextBoxColumn();
            MateriaColumna = new DataGridViewTextBoxColumn();
            BtnRetroceder = new Button();
            ((System.ComponentModel.ISupportInitialize)DataGridListaDocentes).BeginInit();
            SuspendLayout();
            // 
            // DataGridListaDocentes
            // 
            DataGridListaDocentes.BackgroundColor = SystemColors.GradientActiveCaption;
            DataGridListaDocentes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridListaDocentes.Columns.AddRange(new DataGridViewColumn[] { CIColumna, NombreColumna, ApellidoColumna, MateriaColumna });
            DataGridListaDocentes.Location = new Point(37, 12);
            DataGridListaDocentes.Name = "DataGridListaDocentes";
            DataGridListaDocentes.RowTemplate.Height = 25;
            DataGridListaDocentes.Size = new Size(444, 150);
            DataGridListaDocentes.TabIndex = 0;
            DataGridListaDocentes.CellContentClick += dataGridView1_CellContentClick;
            // 
            // CIColumna
            // 
            CIColumna.HeaderText = "CI";
            CIColumna.Name = "CIColumna";
            // 
            // NombreColumna
            // 
            NombreColumna.HeaderText = "Nombre";
            NombreColumna.Name = "NombreColumna";
            // 
            // ApellidoColumna
            // 
            ApellidoColumna.HeaderText = "Apellido";
            ApellidoColumna.Name = "ApellidoColumna";
            // 
            // MateriaColumna
            // 
            MateriaColumna.HeaderText = "Materia";
            MateriaColumna.Name = "MateriaColumna";
            // 
            // BtnRetroceder
            // 
            BtnRetroceder.Location = new Point(489, 355);
            BtnRetroceder.Name = "BtnRetroceder";
            BtnRetroceder.Size = new Size(96, 35);
            BtnRetroceder.TabIndex = 1;
            BtnRetroceder.Text = "Atras";
            BtnRetroceder.UseVisualStyleBackColor = true;
            BtnRetroceder.Click += BtnRetroceder_Click;
            // 
            // Docentes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(623, 413);
            Controls.Add(BtnRetroceder);
            Controls.Add(DataGridListaDocentes);
            Name = "Docentes";
            Text = "Docentes";
            Load += Docentes_Load;
            ((System.ComponentModel.ISupportInitialize)DataGridListaDocentes).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView DataGridListaDocentes;
        private DataGridViewTextBoxColumn CIColumna;
        private DataGridViewTextBoxColumn NombreColumna;
        private DataGridViewTextBoxColumn ApellidoColumna;
        private DataGridViewTextBoxColumn MateriaColumna;
    }
}