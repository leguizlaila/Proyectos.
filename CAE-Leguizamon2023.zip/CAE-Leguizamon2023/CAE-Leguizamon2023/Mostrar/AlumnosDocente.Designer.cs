﻿namespace CAE_Leguizamon2023.Mostrar
{
    partial class AlumnosDocente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridListaAlumnosD = new DataGridView();
            ColumnaCI = new DataGridViewTextBoxColumn();
            ColumnaNombre = new DataGridViewTextBoxColumn();
            ColumnaApellido = new DataGridViewTextBoxColumn();
            ColumnaMatricula = new DataGridViewTextBoxColumn();
            ColumnaCarrera = new DataGridViewTextBoxColumn();
            BtnRetroceder = new Button();
            ((System.ComponentModel.ISupportInitialize)DataGridListaAlumnosD).BeginInit();
            SuspendLayout();
            // 
            // DataGridListaAlumnosD
            // 
            DataGridListaAlumnosD.BackgroundColor = SystemColors.GradientActiveCaption;
            DataGridListaAlumnosD.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridListaAlumnosD.Columns.AddRange(new DataGridViewColumn[] { ColumnaCI, ColumnaNombre, ColumnaApellido, ColumnaMatricula, ColumnaCarrera });
            DataGridListaAlumnosD.GridColor = SystemColors.Desktop;
            DataGridListaAlumnosD.Location = new Point(2, 2);
            DataGridListaAlumnosD.Name = "DataGridListaAlumnosD";
            DataGridListaAlumnosD.RowTemplate.Height = 25;
            DataGridListaAlumnosD.Size = new Size(539, 150);
            DataGridListaAlumnosD.TabIndex = 1;
            // 
            // ColumnaCI
            // 
            ColumnaCI.HeaderText = "CI";
            ColumnaCI.Name = "ColumnaCI";
            // 
            // ColumnaNombre
            // 
            ColumnaNombre.HeaderText = "Nombre";
            ColumnaNombre.Name = "ColumnaNombre";
            // 
            // ColumnaApellido
            // 
            ColumnaApellido.HeaderText = "Apellido";
            ColumnaApellido.Name = "ColumnaApellido";
            // 
            // ColumnaMatricula
            // 
            ColumnaMatricula.HeaderText = "Matricula";
            ColumnaMatricula.Name = "ColumnaMatricula";
            // 
            // ColumnaCarrera
            // 
            ColumnaCarrera.HeaderText = "Carrera";
            ColumnaCarrera.Name = "ColumnaCarrera";
            // 
            // BtnRetroceder
            // 
            BtnRetroceder.Location = new Point(515, 320);
            BtnRetroceder.Name = "BtnRetroceder";
            BtnRetroceder.Size = new Size(91, 30);
            BtnRetroceder.TabIndex = 2;
            BtnRetroceder.Text = "Atras";
            BtnRetroceder.UseVisualStyleBackColor = true;
            BtnRetroceder.Click += BtnRetroceder_Click;
            // 
            // AlumnosDocente
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(647, 415);
            Controls.Add(BtnRetroceder);
            Controls.Add(DataGridListaAlumnosD);
            Name = "AlumnosDocente";
            Text = "AlumnosDocente";
            Load += AlumnosDocente_Load;
            ((System.ComponentModel.ISupportInitialize)DataGridListaAlumnosD).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView DataGridListaAlumnosD;
        private DataGridViewTextBoxColumn ColumnaCI;
        private DataGridViewTextBoxColumn ColumnaNombre;
        private DataGridViewTextBoxColumn ColumnaApellido;
        private DataGridViewTextBoxColumn ColumnaMatricula;
        private DataGridViewTextBoxColumn ColumnaCarrera;
        private Button BtnRetroceder;
    }
}