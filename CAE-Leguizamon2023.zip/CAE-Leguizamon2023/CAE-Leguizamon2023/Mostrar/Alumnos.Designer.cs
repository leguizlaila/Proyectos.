﻿namespace CAE_Leguizamon2023.Mostrar
{
    partial class Alumnos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridListaAlumnos = new DataGridView();
            ColumnaCI = new DataGridViewTextBoxColumn();
            ColumnaNombre = new DataGridViewTextBoxColumn();
            ColumnaApellido = new DataGridViewTextBoxColumn();
            ColumnaMatricula = new DataGridViewTextBoxColumn();
            ColumnaCarrera = new DataGridViewTextBoxColumn();
            BtnRetroceder = new Button();
            ((System.ComponentModel.ISupportInitialize)DataGridListaAlumnos).BeginInit();
            SuspendLayout();
            // 
            // DataGridListaAlumnos
            // 
            DataGridListaAlumnos.BackgroundColor = SystemColors.GradientInactiveCaption;
            DataGridListaAlumnos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridListaAlumnos.Columns.AddRange(new DataGridViewColumn[] { ColumnaCI, ColumnaNombre, ColumnaApellido, ColumnaMatricula, ColumnaCarrera });
            DataGridListaAlumnos.GridColor = SystemColors.Desktop;
            DataGridListaAlumnos.Location = new Point(32, 12);
            DataGridListaAlumnos.Name = "DataGridListaAlumnos";
            DataGridListaAlumnos.RowTemplate.Height = 25;
            DataGridListaAlumnos.Size = new Size(539, 150);
            DataGridListaAlumnos.TabIndex = 0;
            DataGridListaAlumnos.CellContentClick += DataGridListaAlumnos_CellContentClick;
            // 
            // ColumnaCI
            // 
            ColumnaCI.HeaderText = "CI";
            ColumnaCI.Name = "ColumnaCI";
            // 
            // ColumnaNombre
            // 
            ColumnaNombre.HeaderText = "Nombre";
            ColumnaNombre.Name = "ColumnaNombre";
            // 
            // ColumnaApellido
            // 
            ColumnaApellido.HeaderText = "Apellido";
            ColumnaApellido.Name = "ColumnaApellido";
            // 
            // ColumnaMatricula
            // 
            ColumnaMatricula.HeaderText = "Matricula";
            ColumnaMatricula.Name = "ColumnaMatricula";
            // 
            // ColumnaCarrera
            // 
            ColumnaCarrera.HeaderText = "Carrera";
            ColumnaCarrera.Name = "ColumnaCarrera";
            // 
            // BtnRetroceder
            // 
            BtnRetroceder.Location = new Point(498, 378);
            BtnRetroceder.Name = "BtnRetroceder";
            BtnRetroceder.Size = new Size(91, 33);
            BtnRetroceder.TabIndex = 1;
            BtnRetroceder.Text = "Atras";
            BtnRetroceder.UseVisualStyleBackColor = true;
            BtnRetroceder.Click += BtnRetroceder_Click;
            // 
            // Alumnos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(623, 458);
            Controls.Add(BtnRetroceder);
            Controls.Add(DataGridListaAlumnos);
            Name = "Alumnos";
            Text = "Alumnos";
            Load += Alumnos_Load;
            ((System.ComponentModel.ISupportInitialize)DataGridListaAlumnos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView DataGridListaAlumnos;
        private DataGridViewTextBoxColumn ColumnaCI;
        private DataGridViewTextBoxColumn ColumnaNombre;
        private DataGridViewTextBoxColumn ColumnaApellido;
        private DataGridViewTextBoxColumn ColumnaMatricula;
        private DataGridViewTextBoxColumn ColumnaCarrera;
        private Button BtnRetroceder;
    }
}