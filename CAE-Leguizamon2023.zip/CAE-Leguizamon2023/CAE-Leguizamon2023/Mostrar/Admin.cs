﻿using CAE_Leguizamon2023.Funciones.Administrador;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAE_Leguizamon2023.Mostrar
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void Administrador_Load(object sender, EventArgs e)
        {
            JsonAdmin();
        }

        private void JsonAdmin()
        {
            try
            {
                string ruta = @"C:\Users\usuario\Desktop\LP2\CAE-Leguizamon2023\ListaAdmin.json";

                // Lee el contenido del archivo JSON
                string jsonString = File.ReadAllText(ruta);

                // Deserializa el contenido JSON en una lista de 'Datos Administrador'
                List<Datos_Administrador> listaDatos = JsonSerializer.Deserialize<List<Datos_Administrador>>(jsonString);

                // Limpia el DataGridView antes de agregar los datos
                DataGridListaAdmin.Rows.Clear();

                // Agrega cada elemento de la lista al DataGridView
                foreach (Datos_Administrador admin in listaDatos)
                {
                    DataGridListaAdmin.Rows.Add(admin.Ci, admin.nombre, admin.apellido);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos JSON: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnRetroceder_Click_1(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Atras = new AdminFunciones(); // Crea una instancia del formulario anterior
            Atras.Show(); // Muestra el formulario anterior
        }
    }
}
