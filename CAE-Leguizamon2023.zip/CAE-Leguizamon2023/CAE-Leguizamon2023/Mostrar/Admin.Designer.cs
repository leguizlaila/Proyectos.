﻿namespace CAE_Leguizamon2023.Mostrar
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridListaAdmin = new DataGridView();
            ColumnaCi = new DataGridViewTextBoxColumn();
            ColumnaNombre = new DataGridViewTextBoxColumn();
            ColumnaApellido = new DataGridViewTextBoxColumn();
            BtnRetroceder = new Button();
            ((System.ComponentModel.ISupportInitialize)DataGridListaAdmin).BeginInit();
            SuspendLayout();
            // 
            // DataGridListaAdmin
            // 
            DataGridListaAdmin.BackgroundColor = SystemColors.GradientActiveCaption;
            DataGridListaAdmin.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            DataGridListaAdmin.Columns.AddRange(new DataGridViewColumn[] { ColumnaCi, ColumnaNombre, ColumnaApellido });
            DataGridListaAdmin.GridColor = SystemColors.Desktop;
            DataGridListaAdmin.Location = new Point(30, 12);
            DataGridListaAdmin.Name = "DataGridListaAdmin";
            DataGridListaAdmin.RowTemplate.Height = 25;
            DataGridListaAdmin.Size = new Size(345, 150);
            DataGridListaAdmin.TabIndex = 0;
            // 
            // ColumnaCi
            // 
            ColumnaCi.HeaderText = "CI";
            ColumnaCi.Name = "ColumnaCi";
            // 
            // ColumnaNombre
            // 
            ColumnaNombre.HeaderText = "Nombre";
            ColumnaNombre.Name = "ColumnaNombre";
            // 
            // ColumnaApellido
            // 
            ColumnaApellido.HeaderText = "Apellido";
            ColumnaApellido.Name = "ColumnaApellido";
            // 
            // BtnRetroceder
            // 
            BtnRetroceder.Location = new Point(474, 314);
            BtnRetroceder.Name = "BtnRetroceder";
            BtnRetroceder.Size = new Size(88, 32);
            BtnRetroceder.TabIndex = 1;
            BtnRetroceder.Text = "Atras";
            BtnRetroceder.UseVisualStyleBackColor = true;
            BtnRetroceder.Click += BtnRetroceder_Click_1;
            // 
            // Admin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientActiveCaption;
            ClientSize = new Size(574, 375);
            Controls.Add(BtnRetroceder);
            Controls.Add(DataGridListaAdmin);
            Name = "Admin";
            Text = "Administrador";
            Load += Administrador_Load;
            ((System.ComponentModel.ISupportInitialize)DataGridListaAdmin).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView DataGridListaAdmin;
        private DataGridViewTextBoxColumn ColumnaCi;
        private DataGridViewTextBoxColumn ColumnaNombre;
        private DataGridViewTextBoxColumn ColumnaApellido;
        private Button BtnRetroceder;
    }
}