﻿using CAE_Leguizamon2023.Funciones.Administrador;
using CAE_Leguizamon2023.Funciones.Docente;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAE_Leguizamon2023
{
    public partial class ReglamentoCAEDocentes : Form
    {
        public ReglamentoCAEDocentes()
        {
            InitializeComponent();
        }

        private void BtnRetroceder_Click(object sender, EventArgs e)
        {
            this.Hide(); // Oculta el formulario actual
            Form Atras = new Funciones_Docente(); // Crea una instancia del formulario anterior
            Atras.Show(); // Muestra el formulario anterior
        }


    }
}
