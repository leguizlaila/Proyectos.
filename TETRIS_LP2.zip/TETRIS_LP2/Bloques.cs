﻿using System.Collections.Generic;

namespace Tetris_LP2
{
    public abstract class Bloques
    {
        // Representa la forma de los cuadrados del bloque en cada estado de rotación
        protected abstract Posicion[][] Cuadrados { get; }

        // Indica la posición inicial del conjunto de cuadrados del bloque
        protected abstract Posicion EmpezarConjunto { get; }

        // Identificador único del bloque
        public abstract int Id { get; }

        private int EstadoRotacion; // Estado actual de rotación del bloque
        private Posicion DesplazamientoInicial; // Desplazamiento inicial del bloque

        // Constructor de la clase Bloques
        public Bloques()
        {
            // Establece el punto de partida del bloque
            DesplazamientoInicial = new Posicion(EmpezarConjunto.Filas, EmpezarConjunto.Columnas);
        }

        // Devuelve las posiciones de los cuadrados del bloque en su estado actual
        public IEnumerable<Posicion> PosicionCuadro()
        {
            // Recorre los cuadrados del bloque en su estado de rotación actual
            for (int i = 0; i < Cuadrados[EstadoRotacion].Length; i++)
            {
                Posicion p = Cuadrados[EstadoRotacion][i];

                // Devuelve la posición del cuadrado teniendo en cuenta el desplazamiento inicial del bloque
                yield return new Posicion(p.Filas + DesplazamientoInicial.Filas, p.Columnas + DesplazamientoInicial.Columnas);
            }
        }

        // Rota el bloque en sentido horario (como las agujas del reloj)
        public void RotarSH()
        {
            EstadoRotacion++;
            if (EstadoRotacion >= Cuadrados.Length)
            {
                EstadoRotacion = 0; // Volvemos al primer estado de rotación
            }
        }

        // Rota el bloque en sentido antihorario (en contra de las agujas del reloj)
        public void RotarSAH()
        {
            EstadoRotacion--;
            if (EstadoRotacion < 0)
            {
                EstadoRotacion = Cuadrados.Length - 1; // Vamos al último estado de rotación
            }
        }

        // Mueve el bloque en una cantidad de filas y columnas especificada
        public void Mover(int filas, int columnas)
        {
            // Actualiza el desplazamiento inicial del bloque sumando las filas y columnas especificadas
            DesplazamientoInicial = new Posicion(DesplazamientoInicial.Filas + filas, DesplazamientoInicial.Columnas + columnas);
        }

        // Reinicia el bloque a su estado inicial
        public void Reset()
        {
            EstadoRotacion = 0; // Volvemos al primer estado de rotación
            DesplazamientoInicial = new Posicion(EmpezarConjunto.Filas, EmpezarConjunto.Columnas);
        }
    }
}
