﻿using System;
using System.Collections.Generic;

namespace Tetris_LP2
{
    public class ColaBloque
    {
        // Lista que representa la bolsa de bloques disponibles
        private readonly List<Bloques> bolsaBloques = new List<Bloques>
    {
        new BloqueI(),
        new BloqueJ(),
        new BloqueT(),
        new BloqueL(),
        new BloqueS(),
        new BloqueZ(),
        new BloqueO()
    };

        // Instancia de la clase Random para generar números aleatorios
        private readonly Random aleatorio = new Random();

        // Propiedad que almacena el siguiente bloque a ser utilizado
        public Bloques SiguienteBloque { get; private set; }

        public ColaBloque()
        {
            // Al crear una instancia de la clase, se selecciona un bloque aleatorio inicial
            SiguienteBloque = SeleccionarBloqueAleatorio();
        }

        // Método privado para seleccionar un bloque aleatorio de la bolsa
        private Bloques SeleccionarBloqueAleatorio()
        {
            // Se elige un índice aleatorio dentro del rango de la bolsa de bloques
            int indice = aleatorio.Next(bolsaBloques.Count);

            // Se obtiene el bloque correspondiente al íd seleccionado
            Bloques bloque = bolsaBloques[indice];

            // Se remueve el bloque de la bolsa para evitar repeticiones
            bolsaBloques.RemoveAt(indice);

            // Se retorna el bloque seleccionado
            return bloque;
        }

        // Método para obtener el siguiente bloque y actualizar la cola
        public Bloques ObtenerActualizar()
        {
           
            Bloques bloqueActual = SiguienteBloque;

            // Si la bolsa está vacía, se vuelven a agregar los bloques originales
            if (bolsaBloques.Count == 0)
            {
                bolsaBloques.AddRange(new Bloques[]
                {
                new BloqueI(),
                new BloqueJ(),
                new BloqueT(),
                new BloqueL(),
                new BloqueS(),
                new BloqueZ(),
                new BloqueO()
                });
            }

            // Se selecciona un nuevo bloque aleatorio como siguiente bloque
            SiguienteBloque = SeleccionarBloqueAleatorio();

            // Se retorna el bloque actual
            return bloqueActual;
        }
    }
}
