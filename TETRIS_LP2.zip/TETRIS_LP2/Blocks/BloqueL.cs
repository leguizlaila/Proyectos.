﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris_LP2
{
    public class BloqueL : Bloques
    {
        private readonly Posicion[][] cuadrados = new Posicion[][]
       {
            new Posicion[] { new (0,2), new (1,0), new (1,1), new (1,2) },
            new Posicion[] { new (0,1),new (1,1), new (2,1), new(2,2) },
            new Posicion[] { new (1,0),new (1,1), new (1,2), new(2,0) },
            new Posicion[] { new (0,0),new (0,1), new (1,1), new(2,1) }
       };

        public override int Id => 3;
        // Posición inicial en el medio de la pantalla (0,3).
        protected override Posicion EmpezarConjunto => new Posicion(0, 3);
        protected override Posicion[][] Cuadrados => cuadrados;
    }
}
