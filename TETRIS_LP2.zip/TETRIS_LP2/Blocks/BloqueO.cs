﻿namespace Tetris_LP2
{
    public class BloqueO : BloqueI
    {
        private readonly Posicion[][] cuadros = new Posicion[][]
        {
            new Posicion[] { new (0,0), new (0,1), new (1,0), new (1,1) },
        };

        public override int Id => 4;
        // Posición inicial en el medio de la pantalla (0,4).
        protected override Posicion EmpezarConjunto => new Posicion(0, 4);
        protected override Posicion[][] Cuadrados => cuadros;
    }
}
