﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris_LP2
{
    public class EstadoJuego
    {
        private Bloques bloqueActual; // Variable que almacena el bloque actual

        public Bloques BloqueActual
        {
            get => bloqueActual;
            private set
            {
                bloqueActual = value;
                bloqueActual.Reset();

                // Intentar ajustar el bloque en su posición inicial
                // moviéndolo hacia abajo y verificando si se ajusta
                for (int i = 0; i < 2; i++)
                {
                    bloqueActual.Mover(1, 0);

                    if (!AjusteDeBloque())
                    {
                        // Si no se ajusta, revertir el movimiento
                        bloqueActual.Mover(-1, 0);
                    }
                }
            }
        }

        public TableroJuego TableroJuego { get; } // Tablero de juego
        public ColaBloque ColaBloque { get; } // Cola de bloques
        public bool GameOver { get; private set; } // Indicador de fin de juego
        public int Puntaje { get; private set; } // Puntaje del juego

        public EstadoJuego()
        {
            TableroJuego = new TableroJuego(22, 10); // Inicializar el tablero de juego
            ColaBloque = new ColaBloque(); // Inicializar la cola de bloques
            BloqueActual = ColaBloque.ObtenerActualizar(); // Obtener el primer bloque de la cola
        }

        // Método para verificar si el bloque actual se ajusta en el tablero
        private bool AjusteDeBloque()
        {
            foreach (Posicion p in BloqueActual.PosicionCuadro())
            {
                // Verificar si alguna posición del bloque está ocupada en el tablero
                if (!TableroJuego.PVacia(p.Filas, p.Columnas))
                    return false;
            }
            return true;
        }

        // Método para rotar el bloque actual en sentido horario
        public void RotarBloqueSH()
        {
            BloqueActual.RotarSH();

            if (!AjusteDeBloque())
            {
                // Si no se ajusta, revertir la rotación
                BloqueActual.RotarSAH();
            }
        }

        // Método para rotar el bloque actual en sentido antihorario
        public void RotarBloqueSAH()
        {
            BloqueActual.RotarSAH();

            if (!AjusteDeBloque())
            {
                // Si no se ajusta, revertir la rotación
                BloqueActual.RotarSH();
            }
        }

        // Método para mover el bloque actual hacia la izquierda
        public void MoverBloqueIz()
        {
            BloqueActual.Mover(0, -1);

            if (!AjusteDeBloque())
            {
                // Si no se ajusta, revertir el movimiento
                BloqueActual.Mover(0, 1);
            }
        }

        // Método para mover el bloque actual hacia la derecha
        public void MoverBloqueDer()
        {
            BloqueActual.Mover(0, 1);

            if (!AjusteDeBloque())
            {
                // Si no se ajusta, revertir el movimiento
                BloqueActual.Mover(0, -1);
            }
        }

        private bool FinalJuego()
        {
            // Verificar si alguna de las dos primeras filas está ocupada
            return !(TableroJuego.FilaVacia(0) && TableroJuego.FilaVacia(1));
        }

        private void ColocarBloques()
        {
            foreach (Posicion p in BloqueActual.PosicionCuadro())
            {
                // Colocar el bloque actual en el tablero
                TableroJuego[p.Filas, p.Columnas] = BloqueActual.Id;
            }

            Puntaje += TableroJuego.FilasCompletasEliminadas(); // Actualizar el puntaje

            if (FinalJuego())
            {
                GameOver = true; // Si el juego ha finalizado, marcar como Game Over
            }
            else
            {
                BloqueActual = ColaBloque.ObtenerActualizar(); // Obtener el siguiente bloque de la cola
            }
        }

        // Método para mover el bloque actual hacia abajo y colocarlo si no se ajusta
        public void MoverBloqueHAbajo()
        {
            BloqueActual.Mover(1, 0);

            if (!AjusteDeBloque())
            {
                BloqueActual.Mover(-1, 0);
                ColocarBloques();
            }
        }

        // Método para obtener la distancia de caída de un bloque desde una posición
        private int DistanciaCaida(Posicion posicion)
        {
            int distancia = 0;

            while (TableroJuego.PVacia(posicion.Filas + distancia + 1, posicion.Columnas))
            {
                distancia++;
            }
            return distancia;
        }

        // Método para obtener la distancia de caída del bloque actual
        public int DistanciaCaidaBloque()
        {
            int distancia = TableroJuego.Filas;

            foreach (Posicion posicion in BloqueActual.PosicionCuadro())
            {
                // Calcular la menor distancia de caída para cada posición del bloque
                distancia = System.Math.Min(distancia, DistanciaCaida(posicion));
            }
            return distancia;
        }

        // Método para soltar el bloque actual, moverlo hasta su distancia de caída y colocarlo
        public void SoltarBloque()
        {
            BloqueActual.Mover(DistanciaCaidaBloque(), 0);
            ColocarBloques();
        }
    }
}
