﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris_LP2
{
    public class TableroJuego
    {
        private readonly int[,] tablero; // Matriz para representar el tablero de juego
        public int Filas { get; set; } // Número de filas del tablero
        public int Columnas { get; set; } // Número de columnas del tablero

        public int this[int i, int j]
        {
            get => tablero[i, j]; // Índice para acceder a los elementos del tablero
            set => tablero[i, j] = value; // Índice para asignar un valor a los elementos del tablero
        }

        public TableroJuego(int filas, int columnas)
        {
            Filas = filas;
            Columnas = columnas;
            tablero = new int[filas, columnas]; // Inicialización del tablero con el tamaño especificado
        }

        public bool DentroTablero(int i, int j)
        {
            // Verifica si la posición (i, j) está dentro de los límites del tablero
            return i >= 0 && i < Filas && j >= 0 && j < Columnas;
        }

        public bool PVacia(int i, int j)
        {
            // Verifica si la posición (i, j) está dentro del tablero y si está vacía 
            return DentroTablero(i, j) && tablero[i, j] == 0;
        }

        public bool FilaLlena(int i)
        {
            // Verifica si la fila i está completamente llena 
            int j = 0;
            while (j < Columnas)
            {
                if (tablero[i, j] == 0)
                {
                    return false;
                }
                j++;
            }
            return true;

        }

        public bool FilaVacia(int i)
        {
            // Verifica si la fila i está completamente vacía 
            for (int j = 0; j < Columnas; j++)
            {
                if (tablero[i, j] != 0)
                {
                    return false;
                }
            }
            return true;
        }

        private void EliminarFila(int i)
        {
            // Elimina todos los valores de la fila i, estableciéndolos en 0
                for (int j = 0; j < Columnas; j++)
                {
                    tablero[i, j] = 0;
                }
            
        }

        private void MoverFilaHAbajo(int i, int numFilas)
        {
            // Mueve la fila i hacia abajo , reemplazando la fila de abajo
            for (int j = 0; j < Columnas; j++)
            {
                tablero[i + numFilas, j] = tablero[i, j]; // Mueve el valor hacia abajo
                tablero[i, j] = 0; // Establece el valor original en 0
            }
        }

        public int FilasCompletasEliminadas()
        {
            int eliminados = 0; // Contador de filas eliminadas

            for (int i = Filas - 1; i >= 0; i--)
            {
                if (FilaLlena(i))
                {
                    EliminarFila(i); // Elimina la fila i
                    eliminados++; // Incrementa el contador de filas eliminadas
                }
                else if (eliminados > 0)
                {
                    MoverFilaHAbajo(i, eliminados); // Mueve la fila i hacia abajo
                }
            }

            return eliminados; // Devuelve el número total de filas eliminadas
        }
    }
}
