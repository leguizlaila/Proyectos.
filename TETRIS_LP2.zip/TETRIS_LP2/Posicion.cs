﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris_LP2
{
    public class Posicion
    {
        // Propiedades públicas para Filas y Columnas
        public int Filas { get; set; }
        public int Columnas { get; set; }

        // Constructor de la clase Posicion
        public Posicion(int filas, int columnas)
        {
            // Asignar el valor de filas al atributo Filas
            Filas = filas;
            // Asignar el valor de columnas al atributo Columnas
            Columnas = columnas;
        }
    }

}
  