﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Media;

namespace Tetris_LP2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private MediaPlayer mediaPlayer;

        // Imágenes de las piezas del juego
        private readonly ImageSource[] ImagenPiezas = new ImageSource[]
        {
        new BitmapImage(new Uri("Assets/PiezaVacia.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/PiezaRoja.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/PiezaMagenta.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/PiezaAmarilla.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/PiezaCyan.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/PiezaAzul.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/PiezaGris.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/PiezaVerde.png", UriKind.Relative))
        };

        // Imágenes de los bloques del juego
        private readonly ImageSource[] ImagenBloques = new ImageSource[]
        {
        new BitmapImage(new Uri("Assets/Bloque-Vacio.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/Bloque-I.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/Bloque-J.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/Bloque-L.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/Bloque-O.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/Bloque-S.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/Bloque-T.png", UriKind.Relative)),
        new BitmapImage(new Uri("Assets/Bloque-Z.png", UriKind.Relative))
        };

        // Matriz de imágenes que representa el tablero de juego
        private readonly Image[,] ControlDeImagenes;

        // Variables para el control del retardo del juego
        private readonly int MaxRetraso = 1000;
        private readonly int MinRetraso = 100;
        private readonly int DisminucionRetraso = 25;

        // Estado del juego actual
        private EstadoJuego estadoDeJuego = new EstadoJuego();

        public MainWindow()
        {
            InitializeComponent();
            ControlDeImagenes = ConfigurarLienzo(estadoDeJuego.TableroJuego);
        }

        // Configura el lienzo del juego y devuelve la matriz de imágenes correspondiente
        private Image[,] ConfigurarLienzo(TableroJuego tablero)
        {
            Image[,] ControlDeImagenes = new Image[tablero.Filas, tablero.Columnas];
            int tamañoCelda = 25;

            for (int i = 0; i < tablero.Filas; i++)
            {
                for (int j = 0; j < tablero.Columnas; j++)
                {
                    Image ControlImagen = new Image
                    {
                        Width = tamañoCelda,//ancho
                        Height = tamañoCelda//alto
                    };

                    Canvas.SetTop(ControlImagen, (i - 2) * tamañoCelda + 10);//tope
                    Canvas.SetLeft(ControlImagen, j * tamañoCelda);//izquierda
                    GameCanvas.Children.Add(ControlImagen);
                    ControlDeImagenes[i, j] = ControlImagen;
                }
            }
            return ControlDeImagenes;
        }

        // Dibuja el tablero de juego utilizando las imágenes correspondientes
        private void DibujarTablero(TableroJuego tablero)
        {
            for (int i = 0; i < tablero.Filas; i++)
            {
                for (int j = 0; j < tablero.Columnas; j++)
                {
                    int id = tablero[i, j];
                    ControlDeImagenes[i, j].Opacity = 1;
                    ControlDeImagenes[i, j].Source = ImagenPiezas[id];
                }
            }
        }

        // Dibuja los bloques activos en el tablero de juego
        private void DibujarBloques(Bloques bloques)
        {
            foreach (Posicion p in bloques.PosicionCuadro())
            {
                ControlDeImagenes[p.Filas, p.Columnas].Opacity = 1;//totalmente visible
                ControlDeImagenes[p.Filas, p.Columnas].Source = ImagenPiezas[bloques.Id];
            }
        }

        // Dibuja el siguiente bloque en el panel de siguiente bloque
        private void DibujarSiguienteBloque(ColaBloque colabloque)
        {
            Bloques siguiente = colabloque.SiguienteBloque;
            SiguienteImagen.Source = ImagenBloques[siguiente.Id];
        }

        // Dibuja el bloque fantasma que muestra la posición de caída
        private void BloqueFantasma(Bloques bloque)
        {
            int distanciaDeCaida = estadoDeJuego.DistanciaCaidaBloque();

            foreach (Posicion posicion in bloque.PosicionCuadro())
            {
                ControlDeImagenes[posicion.Filas + distanciaDeCaida, posicion.Columnas].Opacity = 0.25;
                ControlDeImagenes[posicion.Filas + distanciaDeCaida, posicion.Columnas].Source = ImagenPiezas[bloque.Id];
            }
        }

        // Dibuja el estado del juego en la interfaz gráfica
        private void Dibujar(EstadoJuego estadoJuego)
        {
            DibujarTablero(estadoJuego.TableroJuego);
            BloqueFantasma(estadoJuego.BloqueActual);
            DibujarBloques(estadoJuego.BloqueActual);
            DibujarSiguienteBloque(estadoJuego.ColaBloque);

            TextoPuntaje.Text = $"Puntaje: {estadoJuego.Puntaje}";
        }

        // Bucle principal del juego
        private async Task BucleDeJuego()
        {
            Dibujar(estadoDeJuego);

            while (!estadoDeJuego.GameOver)
            {
                int demora = Math.Max(MinRetraso, MaxRetraso - (estadoDeJuego.Puntaje * DisminucionRetraso));
                await Task.Delay(demora);
                estadoDeJuego.MoverBloqueHAbajo();
                Dibujar(estadoDeJuego);
            }

            MenuFinJuego.Visibility = Visibility.Visible;
            PuntajeFinalText.Text = $"Puntaje: {estadoDeJuego.Puntaje}";
        }

        // Evento al presionar una tecla en la ventana
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (estadoDeJuego.GameOver)
            {
                return;
            }

            switch (e.Key)
            {
                case Key.Left:
                    estadoDeJuego.MoverBloqueIz();
                    break;
                case Key.Right:
                    estadoDeJuego.MoverBloqueDer();
                    break;
                case Key.Down:
                    estadoDeJuego.MoverBloqueHAbajo();
                    break;
                case Key.Up:
                    estadoDeJuego.RotarBloqueSH();
                    break;
                case Key.Z:
                    estadoDeJuego.RotarBloqueSAH();
                    break;
                case Key.Space:
                    estadoDeJuego.SoltarBloque();
                    break;
                default:
                    return;
            }

            Dibujar(estadoDeJuego);
        }

        // Evento al hacer clic en el lienzo de juego
        private async void LienzoDeJuego(object sender, RoutedEventArgs e)
        {
            await BucleDeJuego();
        }

        // Evento al hacer clic en el botón "Juego Nuevo"
        private async void JuegoNuevo_Click(object sender, RoutedEventArgs e)
        {
            estadoDeJuego = new EstadoJuego();
            MenuFinJuego.Visibility = Visibility.Hidden;
            await BucleDeJuego();
        }
    


    private void Btn_Juegoinfo(object sender, RoutedEventArgs e)
        {
            MessageBox.Show
                ("El Tetris es un juego en el que los jugadores deben encajar diferentes " +
                 "formas geométricas llamadas tetriminos para formar líneas completas. " +
                 "\nObjetivo: El objetivo del Tetris es acumular la mayor cantidad de puntos " +
                 "posible al completar líneas de bloques.\r\n\r\nPiezas: El juego utiliza siete" +
                 " tipos de tetriminos, cada uno compuesto por cuatro bloques cuadrados unidos " +
                 "entre sí. Los tetrominós tienen las siguientes formas: I, J, L, O, S, T, y Z." +
                 "\nLas piezas tetriminos caen desde la parte superior del tablero y los jugadores" +
                 " deben manipularlas para que encajen en el espacio disponible." +
                 "\r\n\r\nMovimiento: Los jugadores pueden mover las piezas hacia la izquierda o " +
                 "hacia la derecha, rotarlas en sentido horario o antihorario, y hacer que caigan" +
                 " más rápido hacia abajo. El objetivo es colocar las piezas en una posición que " +
                 "permita completar líneas horizontales." +
                 "\r\n\r\nLíneas completas: Cuando una línea horizontal se completa sin espacios " +
                 "vacíos, se elimina del tablero y el jugador recibe puntos." +
                 "\r\n\r\nFin del juego: El juego termina cuando las piezas se acumulan hasta la parte" +
                 " superior del tablero, impidiendo que aparezcan nuevas piezas. " +
                 "El objetivo es sobrevivir el mayor tiempo posible y obtener la mayor puntuación" +
                 " posible antes de que esto suceda.");
        }

        private void Btn_SonidoActivado_Click(object sender, RoutedEventArgs e)
        {

            string rutaCancion = "C:/Users/usuario/Desktop/sonido/tetris.mp3";
            mediaPlayer = new MediaPlayer();

            try
            {
                mediaPlayer.Open(new Uri(rutaCancion, UriKind.RelativeOrAbsolute));
                mediaPlayer.Play();
            }
            catch (Exception ex)
            {
                // Manejar cualquier excepción que ocurra al abrir o reproducir la canción
                MessageBox.Show("Error al reproducir la canción: " + ex.Message);
            }
        }

        public void btn_SonidoDesactivado_Click(object sender, RoutedEventArgs e)
        {
            if (mediaPlayer != null && mediaPlayer.Position != TimeSpan.Zero)
            {
                mediaPlayer.Stop();
                mediaPlayer.Close();
                mediaPlayer = null;
            }
        }
    }
}
